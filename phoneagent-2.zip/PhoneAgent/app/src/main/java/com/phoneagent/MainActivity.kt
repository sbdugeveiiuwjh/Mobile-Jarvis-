package com.phoneagent

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val BG = Color.parseColor("#020B1A")
    private val CYAN = Color.parseColor("#00D4FF")
    private val RED = Color.parseColor("#FF2D2D")
    private val GREEN = Color.parseColor("#22FF66")
    private val PANEL = Color.parseColor("#06182E")
    private val MUTED = Color.parseColor("#9FB8D0")

    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var aiStatus: TextView
    private lateinit var sysStatus: TextView
    private lateinit var batteryView: TextView
    private lateinit var accSub: TextView
    private var agent: Agent? = null
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, stroke: Int, radius: Int, strokeW: Int = 2) = GradientDrawable().apply {
        setColor(fill)
        setStroke(dp(strokeW), stroke)
        cornerRadius = dp(radius).toFloat()
    }

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(null, Typeface.BOLD_ITALIC)
        }

    private fun soon() = Toast.makeText(this, "Coming soon", Toast.LENGTH_SHORT).show()

    private fun tile(icon: String, title: String, sub: String, onClick: () -> Unit) =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = box(PANEL, CYAN, 14, 1)
            setPadding(dp(4), dp(10), dp(4), dp(10))
            addView(tv(icon, 24f))
            addView(tv(title, 12f, Color.WHITE, true))
            addView(tv(sub, 10f, MUTED))
            setOnClickListener { onClick() }
        }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach {
            addView(it, LinearLayout.LayoutParams(0, dp(84), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 1)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(14), dp(12), dp(14), dp(8))
        }

        // Header
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val menu = tv("☰", 22f, CYAN).apply { background = box(PANEL, CYAN, 12); setOnClickListener { soon() } }
        val gear = tv("⚙", 22f, CYAN).apply { background = box(PANEL, CYAN, 12); setOnClickListener { settingsDialog() } }
        val credit = tv("Created by Ayush Developer.", 13f).apply {
            background = box(PANEL, CYAN, 16, 1); setPadding(dp(8), dp(10), dp(8), dp(10))
        }
        header.addView(menu, LinearLayout.LayoutParams(dp(46), dp(46)))
        header.addView(credit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(8), 0, dp(8), 0) })
        header.addView(gear, LinearLayout.LayoutParams(dp(46), dp(46)))
        col.addView(header, LinearLayout.LayoutParams(-1, -2))

        // Avatar ring + greeting
        val avatar = ImageView(this).apply {
            setImageResource(R.drawable.avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(PANEL); setStroke(dp(4), CYAN) }
        }
        col.addView(avatar, LinearLayout.LayoutParams(dp(120), dp(120)).apply { topMargin = dp(16) })
        col.addView(tv("\"Hello, Commander! I am JARVIS, your personal AI assistant.\"", 13f, CYAN, true).apply {
            setPadding(dp(8), dp(8), dp(8), 0)
        })

        // Title
        col.addView(tv("JARVIS", 46f, Color.parseColor("#DDE6F0"), true).apply { letterSpacing = 0.08f })
        col.addView(tv("SMART AI ASSISTANT", 12f, Color.WHITE, true))

        // Accessibility tile | Voice | Stop
        val accTile = tile("🛡", "Accessibility", "", { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        accSub = accTile.getChildAt(2) as TextView
        val voice = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(PANEL); setStroke(dp(4), CYAN) }
            addView(tv("🎤", 32f))
            addView(tv("START\nVOICE", 15f, Color.WHITE, true))
            setOnClickListener { startVoice() }
        }
        val stop = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = box(Color.parseColor("#2A0508"), RED, 14)
            addView(tv("■", 28f, RED))
            addView(tv("STOP", 15f, Color.WHITE, true))
            addView(tv("End Session", 10f, RED))
            setOnClickListener { agent?.stopped = true; log("Session ended.") }
        }
        val mainRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        mainRow.addView(accTile, LinearLayout.LayoutParams(0, dp(110), 1f).apply { setMargins(0, 0, dp(6), 0) })
        mainRow.addView(voice, LinearLayout.LayoutParams(dp(140), dp(140)))
        mainRow.addView(stop, LinearLayout.LayoutParams(0, dp(110), 1f).apply { setMargins(dp(6), 0, 0, 0) })
        col.addView(mainRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // Status bar
        aiStatus = tv("", 11f, GREEN, true)
        sysStatus = tv("", 11f, CYAN, true)
        batteryView = tv("", 11f, GREEN, true)
        val status = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = box(PANEL, CYAN, 22, 1)
            setPadding(dp(8), dp(10), dp(8), dp(10))
            addView(aiStatus, LinearLayout.LayoutParams(0, -2, 1f))
            addView(sysStatus, LinearLayout.LayoutParams(0, -2, 1f))
            addView(batteryView, LinearLayout.LayoutParams(0, -2, 1f))
        }
        col.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // Log console
        logView = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.parseColor("#7DF9FF"))
            typeface = Typeface.MONOSPACE
            setPadding(dp(10), dp(8), dp(10), dp(8))
            text = "JARVIS ready. Command bolo ya likho.\n\n"
        }
        logScroll = ScrollView(this).apply {
            background = box(Color.parseColor("#030F20"), CYAN, 12, 1)
            addView(logView)
            setOnTouchListener { v, _ -> v.parent.requestDisallowInterceptTouchEvent(true); false }
        }
        col.addView(logScroll, LinearLayout.LayoutParams(-1, dp(130)).apply { topMargin = dp(12) })

        // Features
        col.addView(tv("JARVIS FEATURES", 15f, CYAN, true), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14) })
        col.addView(row(
            tile("💬", "AI Chat", "Type command") { askDialog() },
            tile("🧠", "Smart Brain", "Examples") { examplesDialog() },
            tile("🚀", "Permissions", "Allow restricted") {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        ))
        col.addView(row(
            tile("▶", "Gaming Hub", "Coming soon") { soon() },
            tile("📊", "Analytics", "Coming soon") { soon() },
            tile("⚙", "More Options", "API key, PIN") { settingsDialog() }
        ))

        root.addView(ScrollView(this).apply { addView(col) }, LinearLayout.LayoutParams(-1, 0, 1f))

        // Bottom nav
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = box(PANEL, CYAN, 0, 1)
            setPadding(0, dp(8), 0, dp(8))
        }
        listOf("🏠" to "Home", "📶" to "Stats", "👑" to "Premium", "👤" to "Profile", "⋮⋮" to "More").forEachIndexed { i, (ic, lb) ->
            val c = if (i == 0) CYAN else MUTED
            nav.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                addView(tv(ic, 18f, c))
                addView(tv(lb, 10f, c))
                if (i > 0) setOnClickListener { soon() }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val hasKey = !prefs.getString("key", "").isNullOrBlank()
        val acc = AgentAccessibilityService.instance != null
        aiStatus.text = if (hasKey) "● AI: Online" else "● AI: No Key"
        aiStatus.setTextColor(if (hasKey) GREEN else RED)
        sysStatus.text = if (acc) "⚡ System: Active" else "⚡ System: Off"
        sysStatus.setTextColor(if (acc) CYAN else RED)
        accSub.text = if (acc) "● Connected" else "● Not Connected"
        accSub.setTextColor(if (acc) GREEN else RED)
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        batteryView.text = "🔋 ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%"
    }

    private fun log(m: String) {
        logView.append(m + "\n\n")
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        try { startActivityForResult(i, 7) } catch (e: Exception) { log("Voice input available nahi hai. AI Chat se type karo.") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK) {
            val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!t.isNullOrBlank()) runTask(t)
        }
    }

    private fun runTask(task: String) {
        val key = prefs.getString("key", "")?.trim() ?: ""
        if (key.isEmpty()) { log("Pehle ⚙ Settings me API key daalo."); settingsDialog(); return }
        if (AgentAccessibilityService.instance == null) {
            log("Pehle Accessibility ON karo.")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val model = prefs.getString("model", "")?.trim().takeUnless { it.isNullOrEmpty() } ?: Agent.GEMINI_MODEL
        val a = Agent(applicationContext, key, prefs.getString("pin", "") ?: "", model) { m -> runOnUiThread { log(m) } }
        agent = a
        log("> $task")
        Thread { a.run(task) }.start()
    }

    private fun askDialog() {
        val et = EditText(this).apply { hint = "Command likho..." }
        AlertDialog.Builder(this).setTitle("AI Chat").setView(et)
            .setPositiveButton("Run") { _, _ -> val t = et.text.toString().trim(); if (t.isNotEmpty()) runTask(t) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun examplesDialog() {
        AlertDialog.Builder(this).setTitle("Example commands")
            .setMessage("• WhatsApp kholo\n• Rahul ko call karo\n• YouTube kholo aur lofi search karo\n• Phone unlock karo\n• Python me calculator likh ke save karo")
            .setPositiveButton("OK", null).show()
    }

    private fun settingsDialog() {
        val lay = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val k = EditText(this).apply {
            hint = "API key (Gemini free ya Claude sk-ant-...)"
            setText(prefs.getString("key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val p = EditText(this).apply {
            hint = "Phone PIN (optional, unlock ke liye)"
            setText(prefs.getString("pin", ""))
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        val mdl = EditText(this).apply {
            hint = "Gemini model (default: ${Agent.GEMINI_MODEL})"
            setText(prefs.getString("model", Agent.GEMINI_MODEL))
        }
        lay.addView(k)
        lay.addView(p)
        lay.addView(mdl)
        AlertDialog.Builder(this).setTitle("Settings").setView(lay)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("key", k.text.toString().trim()).putString("pin", p.text.toString().trim()).putString("model", mdl.text.toString().trim()).apply()
                refreshStatus()
            }
            .setNegativeButton("Cancel", null).show()
    }
}
