package com.phoneagent

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class Agent(
    private val ctx: Context,
    private val apiKey: String,
    private val pin: String,
    private val geminiModel: String,
    private val log: (String) -> Unit
) {
    @Volatile var stopped = false

    companion object {
        const val CLAUDE_MODEL = "claude-sonnet-4-6"
        const val GEMINI_MODEL = "gemini-3.8-flash"
        const val SYSTEM = "You control the user's own Android phone through tools. " +
            "Work step by step: act, then call read_screen to verify before the next action. " +
            "To use an app: open_app, read_screen, then tap_text / type_text / scroll. " +
            "To write code, use write_file. Reply in the same language as the user (Hinglish is fine) and keep replies short. " +
            "Never send money, make purchases, delete data or change security settings; tell the user to do that themselves."
    }

    private class Spec(val name: String, val desc: String, val params: List<Pair<String, String>>)

    private val specs = listOf(
        Spec("open_app", "Open an installed app by its name", listOf("name" to "string")),
        Spec("call_number", "Start a phone call to a number", listOf("number" to "string")),
        Spec("read_screen", "Read the visible screen: elements with [x,y] centers", emptyList()),
        Spec("tap_text", "Tap an element by its visible text or description", listOf("text" to "string")),
        Spec("tap_xy", "Tap screen coordinates", listOf("x" to "number", "y" to "number")),
        Spec("type_text", "Type text into the focused or first input field", listOf("text" to "string")),
        Spec("scroll", "Scroll the screen: direction is 'down' or 'up'", listOf("direction" to "string")),
        Spec("press", "Press a system key: back, home, recents, notifications", listOf("key" to "string")),
        Spec("unlock_phone", "Wake the screen and enter the saved PIN", emptyList()),
        Spec("write_file", "Save a code/text file in the app's files folder", listOf("filename" to "string", "content" to "string")),
        Spec("wait", "Wait some seconds", listOf("seconds" to "number"))
    )

    private fun schema(s: Spec): JSONObject {
        val props = JSONObject()
        val req = JSONArray()
        s.params.forEach { props.put(it.first, JSONObject().put("type", it.second)); req.put(it.first) }
        return JSONObject().put("type", "object").put("properties", props).put("required", req)
    }

    private fun claudeTools(): JSONArray {
        val arr = JSONArray()
        specs.forEach { arr.put(JSONObject().put("name", it.name).put("description", it.desc).put("input_schema", schema(it))) }
        return arr
    }

    private fun geminiTools(): JSONArray {
        val decls = JSONArray()
        specs.forEach {
            val d = JSONObject().put("name", it.name).put("description", it.desc)
            if (it.params.isNotEmpty()) d.put("parameters", schema(it))
            decls.put(d)
        }
        return JSONArray().put(JSONObject().put("functionDeclarations", decls))
    }

    private fun svc() = AgentAccessibilityService.instance

    private fun execute(name: String, a: JSONObject): String {
        return try {
            val s = svc()
            when (name) {
                "open_app" -> {
                    val pm = ctx.packageManager
                    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    val apps = pm.queryIntentActivities(q, 0)
                    val want = a.getString("name")
                    val m = apps.firstOrNull { it.loadLabel(pm).toString().equals(want, true) }
                        ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(want, true) }
                        ?: return "App not found: $want"
                    val i = pm.getLaunchIntentForPackage(m.activityInfo.packageName)!!
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    (s ?: ctx).startActivity(i)
                    Thread.sleep(1500)
                    "Opened ${m.loadLabel(pm)}"
                }
                "call_number" -> {
                    val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + a.getString("number")))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    (s ?: ctx).startActivity(i)
                    "Calling"
                }
                "read_screen" -> s?.readScreen() ?: "Accessibility service is OFF"
                "tap_text" -> if (s?.tapText(a.getString("text")) == true) "Tapped" else "Not found / failed"
                "tap_xy" -> if (s?.tap(a.getDouble("x").toFloat(), a.getDouble("y").toFloat()) == true) "Tapped" else "Failed"
                "type_text" -> if (s?.typeText(a.getString("text")) == true) "Typed" else "No input field found"
                "scroll" -> if (s?.scroll(a.getString("direction")) == true) "Scrolled" else "Failed"
                "press" -> if (s?.press(a.getString("key")) == true) "Pressed" else "Failed"
                "unlock_phone" -> {
                    if (s == null) return "Accessibility service is OFF"
                    if (pin.isBlank()) return "No PIN saved in the app"
                    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
                    @Suppress("DEPRECATION")
                    val wl = pm.newWakeLock(
                        PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "agent:wake"
                    )
                    wl.acquire(5000)
                    Thread.sleep(800)
                    s.swipe(s.screenW / 2, s.screenH * 0.85f, s.screenW / 2, s.screenH * 0.25f, 400)
                    Thread.sleep(800)
                    for (ch in pin) { s.tapText(ch.toString()); Thread.sleep(250) }
                    Thread.sleep(800)
                    "Tried to unlock. Call read_screen to verify."
                }
                "write_file" -> {
                    val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
                    val f = File(dir, File(a.getString("filename")).name)
                    f.writeText(a.getString("content"))
                    "Saved to ${f.absolutePath}"
                }
                "wait" -> { Thread.sleep((a.getDouble("seconds") * 1000).toLong().coerceIn(0, 30000)); "Waited" }
                else -> "Unknown tool"
            }
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): JSONObject {
        var attempt = 0
        while (true) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 30000
            c.readTimeout = 120000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val text = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
            if (code == 429 && attempt < 3) {
                attempt++
                log("Rate limit, 15 sec ruk raha hu...")
                Thread.sleep(15000)
                continue
            }
            if (code >= 400) throw RuntimeException("API error $code: $text")
            return JSONObject(text)
        }
    }

    private fun runClaude(task: String) {
        val tools = claudeTools()
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", task))
        repeat(25) {
            if (stopped) { log("Stopped."); return }
            val body = JSONObject().put("model", CLAUDE_MODEL).put("max_tokens", 1024)
                .put("system", SYSTEM).put("tools", tools).put("messages", messages)
            val resp = post(
                "https://api.anthropic.com/v1/messages",
                mapOf("x-api-key" to apiKey, "anthropic-version" to "2023-06-01"), body
            )
            val content = resp.getJSONArray("content")
            messages.put(JSONObject().put("role", "assistant").put("content", content))
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                when (b.getString("type")) {
                    "text" -> log(b.getString("text"))
                    "tool_use" -> {
                        val n = b.getString("name")
                        log("-> $n ${b.getJSONObject("input")}")
                        val r = execute(n, b.getJSONObject("input"))
                        Thread.sleep(600)
                        results.put(
                            JSONObject().put("type", "tool_result")
                                .put("tool_use_id", b.getString("id")).put("content", r)
                        )
                    }
                }
            }
            if (results.length() == 0) { log("Done."); return }
            messages.put(JSONObject().put("role", "user").put("content", results))
        }
        log("Step limit reached.")
    }

    private fun runGemini(task: String) {
        val tools = geminiTools()
        val contents = JSONArray().put(
            JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", task)))
        )
        repeat(25) {
            if (stopped) { log("Stopped."); return }
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
                .put("contents", contents)
                .put("tools", tools)
            val resp = post(
                "https://generativelanguage.googleapis.com/v1beta/models/$geminiModel:generateContent",
                mapOf("x-goog-api-key" to apiKey), body
            )
            val parts = resp.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")
            if (parts == null || parts.length() == 0) { log("Done."); return }
            contents.put(JSONObject().put("role", "model").put("parts", parts))
            val results = JSONArray()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (p.has("text") && !p.optBoolean("thought")) log(p.getString("text"))
                val fc = p.optJSONObject("functionCall")
                if (fc != null) {
                    val n = fc.getString("name")
                    val args = fc.optJSONObject("args") ?: JSONObject()
                    log("-> $n $args")
                    val r = execute(n, args)
                    Thread.sleep(600)
                    results.put(
                        JSONObject().put(
                            "functionResponse",
                            JSONObject().put("name", n).put("response", JSONObject().put("result", r))
                        )
                    )
                }
            }
            if (results.length() == 0) { log("Done."); return }
            contents.put(JSONObject().put("role", "user").put("parts", results))
        }
        log("Step limit reached.")
    }

    fun run(task: String) {
        try {
            if (apiKey.startsWith("sk-ant")) runClaude(task) else runGemini(task)
        } catch (e: Exception) {
            log("Error: ${e.message}")
        }
    }
}
