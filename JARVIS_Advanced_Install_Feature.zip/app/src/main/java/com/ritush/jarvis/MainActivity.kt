package com.ritush.jarvis

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private val executor = Executors.newSingleThreadExecutor()
    private var voiceCallback: ((String) -> Unit)? = null

    private val voiceLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        voiceCallback?.invoke(spoken ?: "")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            JarvisScreen(
                onVoice = { callback ->
                    voiceCallback = callback
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS ko command dein")
                    }
                    try { voiceLauncher.launch(intent) } catch (_: Exception) { callback("Voice recognition available nahi hai.") }
                },
                onAskGemini = { key, command, callback ->
                    executor.execute {
                        try {
                            val answer = askGemini(key, command)
                            runOnUiThread { callback(answer, null) }
                        } catch (e: Exception) {
                            runOnUiThread { callback(null, e.message ?: "Gemini request failed") }
                        }
                    }
                },
                onExecute = { action, value, query -> executeAction(action, value, query) },
                onSpeak = { speak(it) }
            )
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    // Gemini interprets natural language but cannot directly control Android.
    // The app validates the returned action against this small allowlist.
    private fun askGemini(apiKey: String, command: String): JSONObject {
        val prompt = """
You are JARVIS, a Hindi/Hinglish Android phone assistant.
Convert the user's request into ONE JSON object only, no markdown:
{"action":"OPEN_APP|YOUTUBE_SEARCH|OPEN_SETTINGS|OPEN_CAMERA|SHOW_BATTERY|DIAL_NUMBER|COMPOSE_SMS|ANSWER","value":"string","query":"string","reply":"short Hindi/Hinglish response"}
Rules:
- OPEN_APP value must be one of: youtube, whatsapp, instagram, chrome, gallery, playstore, camera, settings.
- YOUTUBE_SEARCH query is search text.
- DIAL_NUMBER value must be a phone number explicitly supplied by user. Otherwise ANSWER.
- COMPOSE_SMS value/query can describe a draft only; never send it.
- If action is unsupported or unsafe, use ANSWER.
User request: $command
""".trimIndent()

        val encodedKey = URLEncoder.encode(apiKey, "UTF-8")
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent?key=$encodedKey")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("temperature", 0.1).put("responseMimeType", "application/json"))
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val responseText = stream.bufferedReader().use { it.readText() }
        connection.disconnect()
        if (code !in 200..299) throw Exception("Gemini API error $code: ${responseText.take(350)}")
        val response = JSONObject(responseText)
        val text = response.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        return JSONObject(text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim())
    }

    private fun executeAction(action: String, value: String, query: String) {
        when (action) {
            "OPEN_APP" -> {
                val pkg = when (value.lowercase()) {
                    "youtube" -> "com.google.android.youtube"
                    "whatsapp" -> "com.whatsapp"
                    "instagram" -> "com.instagram.android"
                    "chrome" -> "com.android.chrome"
                    "gallery" -> "com.google.android.apps.photos"
                    "playstore" -> "com.android.vending"
                    "camera" -> null
                    "settings" -> null
                    else -> null
                }
                when (value.lowercase()) {
                    "settings" -> startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                    "camera" -> startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
                    else -> {
                        val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
                        if (launch != null) startActivity(launch) else speak("$value app install nahi hai ya open nahi ho sakta.")
                    }
                }
            }
            "YOUTUBE_SEARCH" -> startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")))
            "OPEN_SETTINGS" -> startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            "OPEN_CAMERA" -> startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
            "SHOW_BATTERY" -> {
                val bm = getSystemService(BATTERY_SERVICE) as android.os.BatteryManager
                speak("Battery ${bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)} percent hai.")
            }
            "DIAL_NUMBER" -> {
                if (value.matches(Regex("[+0-9() -]{5,20}"))) {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(value)}")))
                } else speak("Valid number command mein nahi mila. Dialer manually khol raha hoon.")
            }
            "COMPOSE_SMS" -> startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).apply {
                putExtra("sms_body", query.ifBlank { value })
            })
            else -> speak(value.ifBlank { "Main is command ko abhi execute nahi kar sakta." })
        }
    }


    private fun openPlayStoreSearch(appName: String) {
        val safeName = appName.trim()
        if (safeName.isBlank()) {
            speak("App ka naam bataiye.")
            return
        }
        val marketIntent = Intent(Intent.ACTION_VIEW,
            Uri.parse("market://search?q=${Uri.encode(safeName)}&c=apps"))
        try {
            startActivity(marketIntent)
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/search?q=${Uri.encode(safeName)}&c=apps")))
        }
        speak("$safeName ke liye Play Store search khol diya. Install button aap confirm karein.")
    }

    private fun openAppInfo(appName: String) {
        val name = appName.trim()
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = packageManager.queryIntentActivities(launcherIntent, 0).firstOrNull {
            it.loadLabel(packageManager).toString().equals(name, ignoreCase = true)
        } ?: packageManager.queryIntentActivities(launcherIntent, 0).firstOrNull {
            it.loadLabel(packageManager).toString().contains(name, ignoreCase = true)
        }
        if (match == null) {
            speak("$name naam ka installed app nahi mila.")
            return
        }
        val details = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${match.activityInfo.packageName}"))
        startActivity(details)
        speak("$name ki App Info screen khol di. Uninstall aap confirm karein.")
    }

    override fun onDestroy() {
        executor.shutdown()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun JarvisScreen(
    onVoice: ((String) -> Unit) -> Unit,
    onAskGemini: (String, String, (JSONObject?, String?) -> Unit) -> Unit,
    onExecute: (String, String, String) -> Unit,
    onSpeak: (String) -> Unit
) {
    var apiKey by remember { mutableStateOf("") }
    var command by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("READY • GEMINI 3.5 FLASH") }
    var result by remember { mutableStateOf("API key add karke command boliye ya type kijiye.") }
    var pendingAction by remember { mutableStateOf("") }
    var pendingValue by remember { mutableStateOf("") }
    var pendingQuery by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val cyan = Color(0xFF36D9FF)
    val bg = Color(0xFF050B16)

    MaterialTheme(colorScheme = darkColorScheme(
        background = bg, surface = Color(0xFF101B2B), primary = cyan,
        onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(bg).verticalScroll(rememberScrollState()).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(20.dp))
            Text("J.A.R.V.I.S", color = cyan, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("GEMINI 3.5 FLASH • PHONE AGENT", color = Color.LightGray, fontSize = 10.sp)
            Spacer(Modifier.height(22.dp))
            Box(Modifier.size(132.dp).background(Color(0xFF102B40), CircleShape), contentAlignment = Alignment.Center) {
                Text("AI", color = cyan, fontSize = 48.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(16.dp))
            Text(status, color = cyan, fontSize = 11.sp)
            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF101B2B)),
                shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text("GEMINI API KEY", color = cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = apiKey, onValueChange = { apiKey = it },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("Paste your Google AI Studio API key") },
                        visualTransformation = PasswordVisualTransformation()
                    )
                    Text("Key sirf is app session ki memory mein rahegi; app band karne par clear ho jayegi.",
                        color = Color.Gray, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = command, onValueChange = { command = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Apni command likhein") },
                placeholder = { Text("JARVIS, YouTube par Free Fire search karo") }
            )
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onVoice { command = it } }, modifier = Modifier.weight(1f)) {
                    Text("🎙 Speak")
                }
                Button(
                    enabled = !busy && apiKey.isNotBlank() && command.isNotBlank(),
                    onClick = {
                        busy = true; status = "GEMINI THINKING..."
                        onAskGemini(apiKey.trim(), command.trim()) { json, error ->
                            busy = false
                            if (error != null) {
                                status = "API ERROR"
                                result = error
                                pendingAction = ""
                            } else if (json != null) {
                                pendingAction = json.optString("action", "ANSWER")
                                pendingValue = json.optString("value", "")
                                pendingQuery = json.optString("query", "")
                                result = json.optString("reply", "Command samajh aa gayi.")
                                status = "COMMAND READY"
                                onSpeak(result)
                            }
                        }
                    }, modifier = Modifier.weight(1f)
                ) { Text(if (busy) "Thinking..." else "Ask Gemini") }
            }
            Spacer(Modifier.height(16.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF101B2B)),
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("JARVIS RESPONSE", color = cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(result, color = Color.White)
                    if (pendingAction.isNotBlank() && pendingAction != "ANSWER") {
                        Spacer(Modifier.height(14.dp))
                        Text("Action: $pendingAction  ${pendingValue}", color = Color.LightGray, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = {
                            onExecute(pendingAction, pendingValue, pendingQuery)
                            status = "ACTION SENT TO ANDROID"
                            pendingAction = ""
                        }, modifier = Modifier.fillMaxWidth()) { Text("CONFIRM & EXECUTE") }
                        Text("Sensitive actions open system screens for you to review. Nothing is sent secretly.",
                            color = Color.Gray, fontSize = 10.sp)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Examples: YouTube kholo • WhatsApp kholo • Instagram kholo • battery kitni hai • 9876543210 par call screen kholo",
                color = Color.Gray, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            Text("Phone lock bypass, hidden calls/SMS, and unrestricted background control are not supported.",
                color = Color.Gray, fontSize = 10.sp)
        }
    }
}
