# JARVIS Advanced Android — Gemini 3.5 Flash-Lite

## Features in this starter
- Hindi/Hinglish speech input using Android speech-recognition UI.
- Gemini natural-language command interpretation.
- Confirm-before-execute action flow.
- Open installed apps by visible app name.
- Open Google Play Store search for an app install; user taps Install.
- Open Android App Info for an installed app; user confirms uninstall.
- Open Play Store apps/update page.
- YouTube, Google web and Maps search.
- Settings, Camera, battery, time, alarm/timer intents.
- Dialer for a number the user explicitly provides.
- SMS draft only; user reviews and sends.
- GitHub Actions workflow.

## Gemini API
This project uses the official model ID `gemini-3.5-flash-lite` with the Gemini Developer API `generateContent` endpoint.
Create a key at https://aistudio.google.com/app/apikey and paste it in the app.
The API key is held in app memory for the current session only. Do not publish it in GitHub, screenshots, or issue reports. For a public app, proxy calls through a protected backend or use Firebase AI Logic with App Check.

## Build with Android Studio
1. Extract this ZIP.
2. Android Studio > Open > select the extracted project folder.
3. Install Android SDK 35 and JDK 17 if prompted.
4. Wait for Gradle Sync, connect Android phone with USB debugging, press Run.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub — recommended (upload extracted contents)
1. Create a repository.
2. Extract this ZIP on your computer/phone.
3. Upload all extracted files and folders to the repository root (including `.github`).
4. Open Actions, run **Build JARVIS APK**.
5. Download the `JARVIS-debug-apk` artifact from the completed run, extract it, install `app-debug.apk`.

## GitHub — if you want to upload the ZIP file itself
GitHub does not execute a project ZIP just because it is uploaded. First create the repository and add a workflow file at `.github/workflows/build-from-zip.yml` (the separate downloadable workflow supplied with this project). Then upload this project ZIP to the repository root. The workflow extracts it and builds the APK.
Important: the workflow file must be present as an actual file in the repository before Actions can run; a workflow that exists only inside the ZIP cannot start itself.

## Safety / Android limits
- Install flow opens Play Store search; user must tap Install and approve any prompts.
- Uninstall flow opens Android App Info; user must tap Uninstall.
- App updates open Play Store; user selects and confirms.
- Cannot bypass screen lock, silently install/uninstall apps, silently place calls or send SMS, or secretly record.
- Android version/device policy may limit app visibility and some actions.
- This starter project has not been built or tested on a physical device in this environment.
