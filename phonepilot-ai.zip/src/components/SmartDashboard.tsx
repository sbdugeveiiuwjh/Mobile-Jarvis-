import React, { useEffect, useState } from 'react';
import {
  Battery,
  BatteryCharging,
  CloudSun,
  MapPin,
  Mic,
  Wifi,
  WifiOff,
} from 'lucide-react';
import type {
  BatterySnapshot,
  JarvisStatus,
  NetworkSnapshot,
  PermissionStateValue,
  WeatherData,
} from '../types/jarvis.ts';

interface SmartDashboardProps {
  aiStatus: JarvisStatus;
  micPermission: PermissionStateValue;
  isListening: boolean;
  battery: BatterySnapshot;
  network: NetworkSnapshot;
  weather: WeatherData | null;
  weatherLoading: boolean;
  weatherError: string | null;
  onRequestWeather: () => void;
}

export const SmartDashboard: React.FC<SmartDashboardProps> = ({
  aiStatus,
  micPermission,
  isListening,
  battery,
  network,
  weather,
  weatherLoading,
  weatherError,
  onRequestWeather,
}) => {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const timeString = now.toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  const dateString = now.toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  return (
    <section className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-4 space-y-3 shadow-[0_0_24px_rgba(0,212,255,0.08)]">
      <div className="flex items-baseline justify-between gap-3 pb-3 border-b border-cyan-400/20">
        <div>
          <div className="text-xl font-display font-bold text-white tabular-nums">
            {timeString}
          </div>
          <div className="text-xs text-slate-400">{dateString}</div>
        </div>
        <div className="text-right">
          <div className="text-xs font-semibold text-cyan-300 capitalize">
            AI: {aiStatus}
          </div>
          <div className="text-[11px] text-slate-400 inline-flex items-center gap-1 justify-end mt-0.5">
            <Mic className="h-3 w-3 text-cyan-400" />
            <span>
              Mic: {isListening ? 'Listening' : micPermission}
            </span>
          </div>
        </div>
      </div>

      {/* Real Browser Telemetry Grid */}
      <div className="grid grid-cols-2 gap-3 text-xs">
        {/* Battery */}
        <div className="rounded-xl border border-cyan-400/25 bg-[#07182E] p-3">
          <div className="flex items-center gap-1.5 text-slate-300 mb-1">
            {battery.charging ? (
              <BatteryCharging className="h-3.5 w-3.5 text-emerald-400" />
            ) : (
              <Battery className="h-3.5 w-3.5 text-cyan-400" />
            )}
            <span>Battery</span>
          </div>
          <div className="font-semibold text-white tabular-nums">
            {battery.supported && battery.levelPercent !== null
              ? `${battery.levelPercent}% · ${
                  battery.charging ? 'Charging' : 'On battery'
                }`
              : 'Unsupported'}
          </div>
        </div>

        {/* Network */}
        <div className="rounded-xl border border-cyan-400/25 bg-[#07182E] p-3">
          <div className="flex items-center gap-1.5 text-slate-300 mb-1">
            {network.online ? (
              <Wifi className="h-3.5 w-3.5 text-emerald-400" />
            ) : (
              <WifiOff className="h-3.5 w-3.5 text-amber-400" />
            )}
            <span>Network</span>
          </div>
          <div className="font-semibold text-white tabular-nums">
            {network.online
              ? `Online${
                  network.effectiveType
                    ? ` · ${network.effectiveType.toUpperCase()}`
                    : ''
                }`
              : 'Offline'}
          </div>
        </div>
      </div>

      {/* Weather (Location-authorized) */}
      <div className="rounded-xl border border-cyan-400/25 bg-[#07182E] p-3 flex items-center justify-between gap-3">
        {weather ? (
          <>
            <div className="flex items-center gap-2.5 min-w-0">
              <CloudSun className="h-5 w-5 text-cyan-400 shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-semibold text-white tabular-nums">
                  {weather.temperatureC}°C · {weather.condition}
                </div>
                <div className="text-[11px] text-slate-400 tabular-nums truncate">
                  Humidity {weather.humidity}% · {weather.windKmh} km/h
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={onRequestWeather}
              disabled={weatherLoading}
              className="min-h-[36px] px-3 py-1 rounded-full border border-cyan-400/35 hover:border-cyan-300 text-xs text-cyan-100 shrink-0 cursor-pointer"
            >
              {weatherLoading ? '...' : 'Refresh'}
            </button>
          </>
        ) : (
          <>
            <div className="min-w-0">
              <div className="text-xs font-medium text-white flex items-center gap-1.5">
                <MapPin className="h-3.5 w-3.5 text-cyan-400 shrink-0" />
                <span>Local Weather</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5 truncate">
                {weatherError || 'Authorize location'}
              </div>
            </div>
            <button
              type="button"
              onClick={onRequestWeather}
              disabled={weatherLoading}
              className="min-h-[36px] px-3.5 py-1 rounded-full bg-[#00D4FF] hover:bg-cyan-300 text-xs font-bold text-slate-950 shrink-0 whitespace-nowrap cursor-pointer"
            >
              {weatherLoading ? '...' : 'Enable'}
            </button>
          </>
        )}
      </div>
    </section>
  );
};
