import React, { useEffect, useRef, useState } from 'react';
import {
  Camera,
  CameraOff,
  Check,
  Clipboard,
  ClipboardPaste,
  FileUp,
  Flashlight,
  Maximize2,
  Minimize2,
  Monitor,
  MonitorOff,
  Smartphone,
} from 'lucide-react';

interface SelectedFileInfo {
  name: string;
  sizeBytes: number;
  mimeType: string;
  base64Data?: string;
  textContent?: string;
}

interface WebControlsPanelProps {
  cameraStream: MediaStream | null;
  cameraError: string | null;
  torchOn: boolean;
  torchSupported: boolean | null;
  screenStream: MediaStream | null;
  screenError: string | null;
  isFullscreen: boolean;
  onStartCamera: (facingMode: 'environment' | 'user') => Promise<void>;
  onStopCamera: () => void;
  onToggleTorch: () => Promise<void>;
  onStartScreenShare: () => Promise<void>;
  onStopScreenShare: () => void;
  onToggleFullscreen: () => Promise<void>;
  onVibrate: () => string;
  onCopyClipboard: (text: string) => Promise<string>;
  onReadClipboard: () => Promise<{ ok: boolean; value: string }>;
  onAttachFileToChat: (file: SelectedFileInfo) => void;
}

export const WebControlsPanel: React.FC<WebControlsPanelProps> = ({
  cameraStream,
  cameraError,
  torchOn,
  torchSupported,
  screenStream,
  screenError,
  isFullscreen,
  onStartCamera,
  onStopCamera,
  onToggleTorch,
  onStartScreenShare,
  onStopScreenShare,
  onToggleFullscreen,
  onVibrate,
  onCopyClipboard,
  onReadClipboard,
  onAttachFileToChat,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const screenVideoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [facingMode, setFacingMode] = useState<'environment' | 'user'>(
    'environment'
  );
  const [capturedPhotoUrl, setCapturedPhotoUrl] = useState<string | null>(null);
  const [vibrateStatus, setVibrateStatus] = useState<string | null>(null);
  const [clipboardText, setClipboardText] = useState(
    'JARVIS AI command note'
  );
  const [clipboardFeedback, setClipboardFeedback] = useState<string | null>(
    null
  );
  const [selectedFile, setSelectedFile] = useState<SelectedFileInfo | null>(
    null
  );

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.srcObject = cameraStream;
    }
  }, [cameraStream]);

  useEffect(() => {
    if (screenVideoRef.current) {
      screenVideoRef.current.srcObject = screenStream;
    }
  }, [screenStream]);

  const handleCapturePhoto = () => {
    const video = videoRef.current;
    if (!video || !video.videoWidth) return;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL('image/png');
    setCapturedPhotoUrl(dataUrl);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const info: SelectedFileInfo = {
      name: file.name,
      sizeBytes: file.size,
      mimeType: file.type || 'application/octet-stream',
    };

    if (file.type.startsWith('image/') && file.size <= 4 * 1024 * 1024) {
      const reader = new FileReader();
      reader.onload = () => {
        const res = String(reader.result || '');
        const base64 = res.split(',')[1] || '';
        setSelectedFile({ ...info, base64Data: base64 });
      };
      reader.readAsDataURL(file);
    } else if (
      (file.type.startsWith('text/') ||
        /\.(txt|md|json|csv|js|ts|py|html)$/i.test(file.name)) &&
      file.size <= 512 * 1024
    ) {
      const reader = new FileReader();
      reader.onload = () => {
        setSelectedFile({ ...info, textContent: String(reader.result || '') });
      };
      reader.readAsText(file);
    } else {
      setSelectedFile(info);
    }
  };

  return (
    <div className="space-y-5">
      {/* Camera & Torch Section */}
      <div className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-display font-semibold text-white">
              Camera &amp; Flashlight Control
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Uses browser MediaDevices API. Torch requires rear hardware LED support.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {!cameraStream ? (
              <button
                type="button"
                onClick={() => onStartCamera(facingMode)}
                className="min-h-[44px] px-4 py-2 rounded-full bg-[#00D4FF] hover:bg-cyan-300 text-xs font-bold text-slate-950 inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Camera className="h-4 w-4" />
                Authorize &amp; Open Camera
              </button>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => {
                    const next =
                      facingMode === 'environment' ? 'user' : 'environment';
                    setFacingMode(next);
                    void onStartCamera(next);
                  }}
                  className="min-h-[44px] px-3.5 py-2 rounded-full border border-cyan-400/30 bg-[#07182E] hover:bg-[#0B2342] text-xs font-medium text-cyan-100 cursor-pointer"
                >
                  Flip ({facingMode === 'environment' ? 'Rear' : 'Front'})
                </button>
                <button
                  type="button"
                  onClick={handleCapturePhoto}
                  className="min-h-[44px] px-4 py-2 rounded-full bg-[#00D4FF] hover:bg-cyan-300 text-xs font-bold text-slate-950 cursor-pointer"
                >
                  Capture
                </button>
                <button
                  type="button"
                  onClick={onStopCamera}
                  className="min-h-[44px] px-3.5 py-2 rounded-full border border-rose-500/40 bg-rose-500/10 hover:bg-rose-500/20 text-xs font-medium text-rose-200 inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <CameraOff className="h-4 w-4" />
                  Stop
                </button>
              </>
            )}
          </div>
        </div>

        {cameraError && (
          <div className="rounded-xl border border-amber-500/35 bg-amber-500/10 px-4 py-3 text-xs text-amber-200">
            {cameraError}
          </div>
        )}

        {cameraStream && (
          <div className="space-y-3">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full max-h-[280px] rounded-xl bg-black object-cover border border-cyan-400/25"
            />
            <div className="flex flex-wrap items-center justify-between gap-3">
              <button
                type="button"
                onClick={onToggleTorch}
                className={`min-h-[44px] px-4 py-2 rounded-full border text-xs font-semibold inline-flex items-center gap-2 cursor-pointer ${
                  torchOn
                    ? 'bg-amber-400 border-amber-300 text-slate-950'
                    : 'bg-[#07182E] border-cyan-400/30 text-cyan-100 hover:bg-[#0B2342]'
                }`}
              >
                <Flashlight className="h-4 w-4" />
                {torchOn ? 'Turn Flashlight Off' : 'Turn Flashlight On'}
              </button>
              <span className="text-xs text-slate-400">
                {torchSupported === false
                  ? 'Hardware torch unsupported on this browser/camera'
                  : torchSupported === true
                  ? 'Hardware torch available'
                  : 'Tap to test rear torch capability'}
              </span>
            </div>
          </div>
        )}

        {capturedPhotoUrl && (
          <div className="pt-3 border-t border-cyan-400/20 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <img
                src={capturedPhotoUrl}
                alt="Captured camera frame"
                className="h-12 w-12 rounded-xl object-cover border border-cyan-400/30"
              />
              <span className="text-xs text-slate-200">Photo captured</span>
            </div>
            <a
              href={capturedPhotoUrl}
              download={`jarvis-capture-${Date.now()}.png`}
              className="min-h-[40px] px-4 py-2 rounded-full bg-[#07182E] border border-cyan-400/30 hover:bg-[#0B2342] text-xs font-medium text-white inline-flex items-center"
            >
              Download PNG
            </a>
          </div>
        )}
      </div>

      {/* Screen Share & System Actions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Screen Share */}
        <div className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-5 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-sm font-display font-semibold text-white">
              Screen Sharing
            </h3>
            {!screenStream ? (
              <button
                type="button"
                onClick={onStartScreenShare}
                className="min-h-[40px] px-4 py-2 rounded-full bg-[#00D4FF] hover:bg-cyan-300 text-xs font-bold text-slate-950 inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Monitor className="h-3.5 w-3.5" />
                Share Screen
              </button>
            ) : (
              <button
                type="button"
                onClick={onStopScreenShare}
                className="min-h-[40px] px-4 py-2 rounded-full border border-rose-500/40 bg-rose-500/10 text-xs font-semibold text-rose-200 inline-flex items-center gap-1.5 cursor-pointer"
              >
                <MonitorOff className="h-3.5 w-3.5" />
                Stop Sharing
              </button>
            )}
          </div>
          <p className="text-xs text-slate-400">
            Requires explicit browser screen-picker authorization (desktop &amp; supported mobile browsers).
          </p>
          {screenError && (
            <p className="text-xs text-amber-300">{screenError}</p>
          )}
          {screenStream && (
            <video
              ref={screenVideoRef}
              autoPlay
              playsInline
              muted
              className="w-full max-h-[160px] rounded-xl bg-black object-contain border border-cyan-400/25"
            />
          )}
        </div>

        {/* Vibration & Fullscreen */}
        <div className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-5 space-y-3">
          <h3 className="text-sm font-display font-semibold text-white">
            Haptics &amp; Display
          </h3>
          <div className="flex flex-wrap gap-2.5">
            <button
              type="button"
              onClick={() => setVibrateStatus(onVibrate())}
              className="min-h-[44px] px-4 py-2 rounded-full border border-cyan-400/30 bg-[#07182E] hover:bg-[#0B2342] text-xs font-semibold text-cyan-100 inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Smartphone className="h-4 w-4 text-cyan-400" />
              Test Vibration
            </button>
            <button
              type="button"
              onClick={onToggleFullscreen}
              className="min-h-[44px] px-4 py-2 rounded-full border border-cyan-400/30 bg-[#07182E] hover:bg-[#0B2342] text-xs font-semibold text-cyan-100 inline-flex items-center gap-1.5 cursor-pointer"
            >
              {isFullscreen ? (
                <>
                  <Minimize2 className="h-4 w-4 text-cyan-400" />
                  Exit Fullscreen
                </>
              ) : (
                <>
                  <Maximize2 className="h-4 w-4 text-cyan-400" />
                  Enter Fullscreen
                </>
              )}
            </button>
          </div>
          <p className="text-xs text-slate-400">
            {vibrateStatus ||
              'Trigger device haptic pulse or toggle browser fullscreen mode.'}
          </p>
        </div>
      </div>

      {/* Clipboard & File Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Clipboard */}
        <div className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-5 space-y-3">
          <h3 className="text-sm font-display font-semibold text-white">
            Clipboard Access
          </h3>
          <input
            type="text"
            value={clipboardText}
            onChange={(e) => setClipboardText(e.target.value)}
            className="w-full min-h-[44px] rounded-full border border-cyan-400/30 bg-[#07182E] px-4 text-xs text-white focus:outline-none focus:border-cyan-300"
          />
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={async () => {
                const msg = await onCopyClipboard(clipboardText);
                setClipboardFeedback(msg);
              }}
              className="min-h-[40px] px-4 py-2 rounded-full bg-[#00D4FF] hover:bg-cyan-300 text-xs font-bold text-slate-950 inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Clipboard className="h-3.5 w-3.5" />
              Copy Text
            </button>
            <button
              type="button"
              onClick={async () => {
                const res = await onReadClipboard();
                if (res.ok) {
                  setClipboardText(res.value);
                  setClipboardFeedback('Clipboard text loaded.');
                } else {
                  setClipboardFeedback(res.value);
                }
              }}
              className="min-h-[40px] px-4 py-2 rounded-full border border-cyan-400/30 bg-[#07182E] hover:bg-[#0B2342] text-xs font-semibold text-cyan-100 inline-flex items-center gap-1.5 cursor-pointer"
            >
              <ClipboardPaste className="h-3.5 w-3.5" />
              Read Clipboard
            </button>
          </div>
          {clipboardFeedback && (
            <p className="text-xs text-slate-300">{clipboardFeedback}</p>
          )}
        </div>

        {/* File Selection */}
        <div className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-5 space-y-3">
          <h3 className="text-sm font-display font-semibold text-white">
            File Selection &amp; AI Analysis
          </h3>
          <input
            ref={fileInputRef}
            type="file"
            onChange={handleFileChange}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="w-full min-h-[44px] px-4 py-2 rounded-full border border-dashed border-cyan-400/40 bg-[#07182E] hover:bg-[#0B2342] text-xs font-semibold text-cyan-100 inline-flex items-center justify-center gap-2 cursor-pointer"
          >
            <FileUp className="h-4 w-4 text-cyan-400" />
            Choose File from Device
          </button>

          {selectedFile ? (
            <div className="rounded-xl border border-cyan-400/25 bg-[#07182E] p-3 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="text-xs font-semibold text-white truncate">
                  {selectedFile.name}
                </div>
                <div className="text-[11px] text-slate-400 tabular-nums">
                  {Math.max(1, Math.round(selectedFile.sizeBytes / 1024))} KB ·{' '}
                  {selectedFile.mimeType}
                </div>
              </div>
              {(selectedFile.base64Data || selectedFile.textContent) && (
                <button
                  type="button"
                  onClick={() => onAttachFileToChat(selectedFile)}
                  className="min-h-[36px] px-3.5 py-1.5 rounded-full bg-[#00D4FF] hover:bg-cyan-300 text-xs font-bold text-slate-950 inline-flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  <Check className="h-3.5 w-3.5" />
                  Analyze
                </button>
              )}
            </div>
          ) : (
            <p className="text-xs text-slate-400">
              Select an image or text file to inspect metadata or attach to JARVIS AI.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
