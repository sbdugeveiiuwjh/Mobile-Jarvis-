import React, { useEffect, useRef } from 'react';
import { Mic, MicOff, VolumeX } from 'lucide-react';
import type { JarvisStatus } from '../types/jarvis.ts';

interface JarvisCoreProps {
  status: JarvisStatus;
  isListening: boolean;
  isSpeaking: boolean;
  wakeWordEnabled: boolean;
  interimTranscript: string;
  audioStream: MediaStream | null;
  onToggleListen: () => void;
  onStopSpeaking: () => void;
}

const STATUS_LABELS: Record<JarvisStatus, string> = {
  idle: 'Standing By',
  listening: 'Listening to Voice',
  thinking: 'Processing Intent',
  speaking: 'Speaking Response',
  error: 'Attention Needed',
};

export const JarvisCore: React.FC<JarvisCoreProps> = ({
  status,
  isListening,
  isSpeaking,
  wakeWordEnabled,
  interimTranscript,
  audioStream,
  onToggleListen,
  onStopSpeaking,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId = 0;
    let audioCtx: AudioContext | null = null;
    let analyser: AnalyserNode | null = null;
    let source: MediaStreamAudioSourceNode | null = null;
    let dataArray: Uint8Array<ArrayBuffer> | null = null;

    if (audioStream && isListening) {
      try {
        const AudioContextCtor =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext })
            .webkitAudioContext;
        audioCtx = new AudioContextCtor();
        analyser = audioCtx.createAnalyser();
        analyser.fftSize = 64;
        source = audioCtx.createMediaStreamSource(audioStream);
        source.connect(analyser);
        dataArray = new Uint8Array(new ArrayBuffer(analyser.frequencyBinCount));
      } catch {
        analyser = null;
      }
    }

    let phase = 0;

    const draw = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const barCount = 28;
      const gap = 4;
      const barWidth = (width - gap * (barCount - 1)) / barCount;

      if (analyser && dataArray && isListening) {
        analyser.getByteFrequencyData(dataArray);
        for (let i = 0; i < barCount; i++) {
          const val = dataArray[i % dataArray.length] || 0;
          const barHeight = Math.max(4, (val / 255) * (height - 6));
          const x = i * (barWidth + gap);
          const y = (height - barHeight) / 2;
          ctx.fillStyle = '#3B82F6';
          ctx.fillRect(x, y, barWidth, barHeight);
        }
      } else if (isSpeaking || status === 'thinking') {
        phase += isSpeaking ? 0.16 : 0.08;
        for (let i = 0; i < barCount; i++) {
          const wave = Math.sin(phase + i * 0.45) * 0.5 + 0.5;
          const barHeight = 4 + wave * (isSpeaking ? height * 0.68 : height * 0.35);
          const x = i * (barWidth + gap);
          const y = (height - barHeight) / 2;
          ctx.fillStyle = isSpeaking ? '#3B82F6' : 'rgba(59, 130, 246, 0.55)';
          ctx.fillRect(x, y, barWidth, barHeight);
        }
      } else {
        for (let i = 0; i < barCount; i++) {
          const x = i * (barWidth + gap);
          const y = height / 2 - 1.5;
          ctx.fillStyle = 'rgba(161, 161, 170, 0.32)';
          ctx.fillRect(x, y, barWidth, 3);
        }
      }

      animationId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animationId);
      source?.disconnect();
      if (audioCtx && audioCtx.state !== 'closed') {
        void audioCtx.close();
      }
    };
  }, [audioStream, isListening, isSpeaking, status]);

  const coreAccent =
    status === 'error'
      ? 'text-amber-400'
      : isListening
      ? 'text-blue-300'
      : 'text-blue-400';

  return (
    <section className="rounded-3xl border border-white/10 bg-[#121214] p-6 flex flex-col items-center text-center">
      {/* Status Line */}
      <div className="w-full flex items-center justify-between text-xs text-zinc-400 mb-3">
        <span className="font-medium text-zinc-200">
          {STATUS_LABELS[status]}
        </span>
        <span className="tabular-nums">
          {wakeWordEnabled ? 'Wake-word: "Jarvis"' : 'Tap mic to speak'}
        </span>
      </div>

      {/* Animated Circular AI Core */}
      <div className="relative h-48 w-48 flex items-center justify-center my-2">
        <svg
          viewBox="0 0 200 200"
          className={`absolute inset-0 h-full w-full ${
            isListening || status === 'thinking'
              ? 'animate-jarvis-slow'
              : ''
          }`}
          aria-hidden="true"
        >
          <circle
            cx="100"
            cy="100"
            r="92"
            fill="none"
            stroke="rgba(59, 130, 246, 0.18)"
            strokeWidth="2"
          />
          <circle
            cx="100"
            cy="100"
            r="80"
            fill="none"
            stroke="#3B82F6"
            strokeOpacity={isListening ? '0.95' : '0.5'}
            strokeWidth="4"
            strokeDasharray="34 16 12 16"
            strokeLinecap="round"
          />
        </svg>

        <svg
          viewBox="0 0 200 200"
          className="absolute inset-0 h-full w-full animate-jarvis-reverse"
          aria-hidden="true"
        >
          <circle
            cx="100"
            cy="100"
            r="64"
            fill="none"
            stroke="#2B7DE9"
            strokeOpacity="0.65"
            strokeWidth="3"
            strokeDasharray="18 14"
            strokeLinecap="round"
          />
        </svg>

        {/* Central Interactive Mic Trigger */}
        <button
          type="button"
          onClick={onToggleListen}
          aria-label={isListening ? 'Stop listening' : 'Activate voice input'}
          aria-pressed={isListening}
          className={`relative z-10 h-24 w-24 rounded-full border flex flex-col items-center justify-center gap-1 transition-all duration-150 cursor-pointer ${
            isListening
              ? 'bg-[#2B7DE9]/25 border-blue-400 shadow-[0_0_32px_rgba(43,125,233,0.45)] scale-105'
              : 'bg-[#1C1C1E] border-white/15 hover:border-blue-400/60 hover:bg-[#2B7DE9]/15'
          }`}
        >
          {isListening ? (
            <MicOff className={`h-7 w-7 ${coreAccent}`} />
          ) : (
            <Mic className={`h-7 w-7 ${coreAccent}`} />
          )}
          <span className="text-[11px] font-display font-semibold tracking-wide text-zinc-100">
            {isListening ? 'STOP' : 'SPEAK'}
          </span>
        </button>
      </div>

      {/* Live Voice Waveform */}
      <div className="w-full max-w-[260px] mt-2">
        <canvas
          ref={canvasRef}
          width={260}
          height={42}
          className="w-full h-[42px]"
          aria-label="Voice audio waveform"
        />
      </div>

      {/* Live Interim Transcript or TTS Stop */}
      <div className="min-h-[28px] mt-2 flex items-center justify-center">
        {interimTranscript ? (
          <p className="text-xs text-blue-300 line-clamp-2">
            &ldquo;{interimTranscript}&rdquo;
          </p>
        ) : isSpeaking ? (
          <button
            type="button"
            onClick={onStopSpeaking}
            className="min-h-[36px] px-3.5 py-1.5 rounded-full border border-amber-500/40 bg-amber-500/10 hover:bg-amber-500/20 text-xs font-medium text-amber-200 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <VolumeX className="h-3.5 w-3.5" />
            Stop Voice Output
          </button>
        ) : (
          <p className="text-xs text-zinc-400">
            Supports Hindi, Hinglish, and English commands
          </p>
        )}
      </div>
    </section>
  );
};
