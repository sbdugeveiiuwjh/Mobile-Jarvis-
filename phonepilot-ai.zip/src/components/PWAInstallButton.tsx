import React, { useState } from 'react';
import { Download } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall.ts';

interface PWAInstallButtonProps {
  onFallbackReset?: () => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  onFallbackReset,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    if (!onFallbackReset) return null;
    return (
      <button
        type="button"
        onClick={onFallbackReset}
        className="min-h-[40px] px-3.5 py-1.5 rounded-full bg-[#07182E] border border-cyan-400/35 hover:bg-[#0B2342] text-xs font-medium text-cyan-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
      >
        New Chat
      </button>
    );
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className="min-h-[40px] px-4 py-1.5 rounded-full bg-[#00D4FF] hover:bg-cyan-300 text-xs font-bold text-slate-950 inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
      >
        <Download className="h-3.5 w-3.5" />
        <span>Install App</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className="min-h-[40px] px-3.5 py-1.5 rounded-full bg-[#07182E] border border-cyan-400/35 hover:bg-[#0B2342] text-xs font-medium text-cyan-100 inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Download className="h-3.5 w-3.5" />
          <span>Install</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <div className="w-full max-w-sm rounded-2xl border border-cyan-400/40 bg-[#041022] p-6 text-slate-100 shadow-2xl">
              <h3 className="text-base font-display font-semibold text-white">
                Install JARVIS AI on iPhone / iPad
              </h3>
              <p className="mt-2.5 text-sm text-slate-300 leading-relaxed">
                1. Tap the <strong>Share</strong> icon in the Safari toolbar.
                <br />
                2. Scroll down and tap <strong>Add to Home Screen</strong>.
              </p>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full min-h-[44px] rounded-full bg-[#00D4FF] hover:bg-cyan-300 text-sm font-bold text-slate-950 cursor-pointer"
              >
                Got it
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  if (!onFallbackReset) return null;
  return (
    <button
      type="button"
      onClick={onFallbackReset}
      className="min-h-[40px] px-3.5 py-1.5 rounded-full bg-[#07182E] border border-cyan-400/35 hover:bg-[#0B2342] text-xs font-medium text-cyan-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
    >
      New Chat
    </button>
  );
};
