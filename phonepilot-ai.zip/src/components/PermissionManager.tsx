import React from 'react';
import { RefreshCw, ShieldCheck } from 'lucide-react';
import type { PermissionMatrix, PermissionStateValue } from '../types/jarvis.ts';

interface PermissionManagerProps {
  permissions: PermissionMatrix;
  onRefresh: () => Promise<void>;
  onRequestMic: () => Promise<void>;
  onRequestCamera: () => Promise<void>;
  onRequestLocation: () => Promise<void>;
  onRequestNotifications: () => Promise<void>;
}

function formatStateLabel(val: PermissionStateValue): {
  label: string;
  tone: string;
} {
  switch (val) {
    case 'granted':
      return { label: 'Granted', tone: 'text-emerald-400' };
    case 'denied':
      return { label: 'Denied', tone: 'text-rose-400' };
    case 'prompt':
      return { label: 'Ask on Use', tone: 'text-amber-300' };
    case 'unsupported':
      return { label: 'Unsupported', tone: 'text-slate-500' };
    default:
      return { label: 'Browser Managed', tone: 'text-slate-400' };
  }
}

export const PermissionManager: React.FC<PermissionManagerProps> = ({
  permissions,
  onRefresh,
  onRequestMic,
  onRequestCamera,
  onRequestLocation,
  onRequestNotifications,
}) => {
  const permissionRows: Array<{
    key: string;
    name: string;
    desc: string;
    status: PermissionStateValue;
    onRequest?: () => Promise<void>;
  }> = [
    {
      key: 'microphone',
      name: 'Microphone Access',
      desc: 'Used for voice commands and live audio waveform.',
      status: permissions.microphone,
      onRequest: onRequestMic,
    },
    {
      key: 'camera',
      name: 'Camera Access',
      desc: 'Used for live camera preview, photo capture, and torch test.',
      status: permissions.camera,
      onRequest: onRequestCamera,
    },
    {
      key: 'geolocation',
      name: 'Location Access',
      desc: 'Used exclusively when loading local weather.',
      status: permissions.geolocation,
      onRequest: onRequestLocation,
    },
    {
      key: 'clipboard',
      name: 'Clipboard Read',
      desc: 'Allows reading copied text when explicitly requested.',
      status: permissions.clipboardRead,
    },
    {
      key: 'notifications',
      name: 'Browser Notifications',
      desc: 'Optional desktop/mobile alert notifications.',
      status: permissions.notifications,
      onRequest: onRequestNotifications,
    },
  ];

  const capabilityList: Array<{ name: string; supported: boolean }> = [
    { name: 'Speech Recognition (Web Speech API)', supported: permissions.speechRecognition },
    { name: 'Speech Synthesis (Text-to-Speech)', supported: permissions.speechSynthesis },
    { name: 'Battery Status API', supported: permissions.batteryApi },
    { name: 'Vibration API', supported: permissions.vibrationApi },
    { name: 'Fullscreen API', supported: permissions.fullscreenApi },
    { name: 'Screen Sharing (getDisplayMedia)', supported: permissions.screenShareApi },
  ];

  return (
    <div className="space-y-5">
      <div className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="h-5 w-5 text-cyan-400" />
            <div>
              <h2 className="text-base font-display font-semibold text-white">
                Browser Permission Manager
              </h2>
              <p className="text-xs text-slate-400">
                Real browser permission state. Sensitive APIs are never accessed without your consent.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onRefresh}
            className="min-h-[40px] px-4 py-2 rounded-full border border-cyan-400/30 bg-[#07182E] hover:bg-[#0B2342] text-xs font-medium text-cyan-100 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Refresh
          </button>
        </div>

        <div className="divide-y divide-cyan-400/15">
          {permissionRows.map((row) => {
            const meta = formatStateLabel(row.status);
            return (
              <div
                key={row.key}
                className="py-3.5 flex flex-wrap items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <div className="text-sm font-medium text-white">
                    {row.name}
                  </div>
                  <div className="text-xs text-slate-400">{row.desc}</div>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className={`text-xs font-semibold ${meta.tone}`}>
                    {meta.label}
                  </span>
                  {row.onRequest && row.status !== 'granted' && row.status !== 'unsupported' && (
                    <button
                      type="button"
                      onClick={row.onRequest}
                      className="min-h-[38px] px-3.5 py-1.5 rounded-full bg-[#00D4FF] hover:bg-cyan-300 text-xs font-bold text-slate-950 cursor-pointer"
                    >
                      Authorize
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Hardware / Browser API Support Matrix */}
      <div className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-5">
        <h3 className="text-sm font-display font-semibold text-white mb-3">
          Detected Browser Web API Support
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {capabilityList.map((cap) => (
            <div
              key={cap.name}
              className="rounded-xl border border-cyan-400/20 bg-[#07182E] px-4 py-3 flex items-center justify-between gap-2 text-xs"
            >
              <span className="text-slate-200">{cap.name}</span>
              <span
                className={
                  cap.supported
                    ? 'font-semibold text-emerald-400'
                    : 'font-semibold text-slate-500'
                }
              >
                {cap.supported ? 'Supported' : 'Unavailable'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
