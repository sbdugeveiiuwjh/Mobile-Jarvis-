import React, { useMemo, useRef, useState } from 'react';
import {
  Camera,
  ExternalLink,
  Instagram,
  MapPin,
  MessageCircle,
  MessageSquare,
  Mic,
  MicOff,
  Music,
  Phone,
  PlaySquare,
  Plus,
  Search,
  Smartphone,
  Trash2,
} from 'lucide-react';
import type { AppShortcut } from '../types/jarvis.ts';
import { resolveAppLaunchTarget } from '../utils/appDirectory.ts';

interface AppLauncherPanelProps {
  shortcuts: AppShortcut[];
  isListening: boolean;
  onToggleVoiceCommand: () => void;
  onAddShortcut: (name: string, url: string) => void;
  onRemoveShortcut: (id: string) => void;
  onOpenCameraControl: () => void;
}

function getAppIcon(id: string, name: string) {
  const key = `${id} ${name}`.toLowerCase();
  if (key.includes('youtube')) return PlaySquare;
  if (key.includes('instagram')) return Instagram;
  if (key.includes('whatsapp')) return MessageCircle;
  if (key.includes('google') && !key.includes('maps') && !key.includes('play'))
    return Search;
  if (key.includes('maps')) return MapPin;
  if (key.includes('spotify') || key.includes('music')) return Music;
  if (key.includes('phone') || key.includes('dialer') || key.includes('call'))
    return Phone;
  if (key.includes('message') || key.includes('sms')) return MessageSquare;
  return Smartphone;
}

function isWebProtocol(url: string): boolean {
  return url.startsWith('http://') || url.startsWith('https://');
}

export const AppLauncherPanel: React.FC<AppLauncherPanelProps> = ({
  shortcuts,
  isListening,
  onToggleVoiceCommand,
  onAddShortcut,
  onRemoveShortcut,
  onOpenCameraControl,
}) => {
  const [ytQuery, setYtQuery] = useState('');
  const [appName, setAppName] = useState('');
  const [customScheme, setCustomScheme] = useState('');
  const [showSchemeInput, setShowSchemeInput] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const ytAnchorRef = useRef<HTMLAnchorElement | null>(null);

  const youtubeSearchUrl = useMemo(() => {
    const q = ytQuery.trim();
    return q
      ? `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`
      : 'https://www.youtube.com';
  }, [ytQuery]);

  const resolvedCustomApp = useMemo(() => {
    if (!appName.trim()) return null;
    return resolveAppLaunchTarget(appName, customScheme);
  }, [appName, customScheme]);

  const handleYtSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    ytAnchorRef.current?.click();
  };

  const handleSaveApp = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    const trimmed = appName.trim();
    if (!trimmed) {
      setFormError('Enter an app name (e.g. Spotify, Flipkart, Snapchat).');
      return;
    }
    const target = resolveAppLaunchTarget(trimmed, customScheme);
    onAddShortcut(target.appName, target.url);
    setAppName('');
    setCustomScheme('');
    setShowSchemeInput(false);
  };

  return (
    <div className="space-y-5">
      {/* Main App Launcher Card */}
      <div className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-5 space-y-5 shadow-[0_0_24px_rgba(0,212,255,0.08)]">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-display font-semibold text-white">
              Smart App Launcher
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              One-tap &amp; voice launch for YouTube (with search), Instagram, WhatsApp, Google, Camera, and other apps.
            </p>
          </div>
          <button
            type="button"
            onClick={onToggleVoiceCommand}
            className={`min-h-[40px] px-4 py-2 rounded-full border text-xs font-bold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
              isListening
                ? 'bg-rose-600 border-rose-500 text-white hover:bg-rose-500'
                : 'bg-[#00D4FF] border-transparent text-slate-950 hover:bg-cyan-300'
            }`}
          >
            {isListening ? (
              <>
                <MicOff className="h-3.5 w-3.5" />
                <span>Stop Voice</span>
              </>
            ) : (
              <>
                <Mic className="h-3.5 w-3.5" />
                <span>Voice App Launch</span>
              </>
            )}
          </button>
        </div>

        {/* Direct YouTube Search Bar */}
        <form
          onSubmit={handleYtSubmit}
          className="rounded-full border border-cyan-400/35 bg-[#07182E] pl-4 pr-1.5 py-1.5 flex items-center gap-2.5"
        >
          <PlaySquare className="h-5 w-5 text-rose-400 shrink-0" />
          <input
            type="text"
            value={ytQuery}
            onChange={(e) => setYtQuery(e.target.value)}
            placeholder="Search on YouTube (e.g. lo-fi music, Arijit Singh)..."
            className="flex-1 min-w-0 min-h-[38px] bg-transparent text-sm text-white placeholder:text-slate-400 focus:outline-none"
          />
          <a
            ref={ytAnchorRef}
            href={youtubeSearchUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="min-h-[38px] px-4 rounded-full bg-[#00D4FF] hover:bg-cyan-300 text-xs font-bold text-slate-950 inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Search className="h-3.5 w-3.5" />
            <span>{ytQuery.trim() ? 'Search' : 'Open'}</span>
          </a>
        </form>

        {/* One-Tap App Tiles */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {/* Built-in Camera App */}
          <button
            type="button"
            onClick={onOpenCameraControl}
            className="min-h-[68px] rounded-xl border border-cyan-400/30 bg-[#07182E] hover:border-cyan-300 hover:bg-[#0B2342] p-3.5 flex items-center justify-between gap-2 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="h-10 w-10 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center shrink-0">
                <Camera className="h-5 w-5 text-cyan-300" />
              </div>
              <div className="min-w-0">
                <div className="text-sm font-semibold text-white truncate">
                  Camera
                </div>
                <div className="text-[11px] text-slate-400 truncate">
                  One-tap Camera
                </div>
              </div>
            </div>
          </button>

          {/* Built-in & Custom App Tiles */}
          {shortcuts.map((item) => {
            const Icon = getAppIcon(item.id, item.name);
            const openInNewTab = isWebProtocol(item.url);
            return (
              <div
                key={item.id}
                className="relative min-h-[68px] rounded-xl border border-cyan-400/30 bg-[#07182E] hover:border-cyan-300 transition-colors flex items-center justify-between p-3.5 gap-2"
              >
                <a
                  href={item.url}
                  target={openInNewTab ? '_blank' : undefined}
                  rel={openInNewTab ? 'noopener noreferrer' : undefined}
                  className="flex items-center gap-3 min-w-0 flex-1"
                >
                  <div className="h-10 w-10 rounded-xl bg-[#0A2240] border border-cyan-400/25 flex items-center justify-center shrink-0">
                    <Icon className="h-5 w-5 text-cyan-300" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-white truncate flex items-center gap-1">
                      <span className="truncate">{item.name}</span>
                      <ExternalLink className="h-3 w-3 text-cyan-400/70 shrink-0" />
                    </div>
                    <div className="text-[11px] text-slate-400 truncate">
                      {item.subtitle || 'Tap to open app'}
                    </div>
                  </div>
                </a>
                {item.isCustom && (
                  <button
                    type="button"
                    onClick={() => onRemoveShortcut(item.id)}
                    aria-label={`Remove ${item.name}`}
                    className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-full text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 shrink-0 cursor-pointer"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Open or Add Any App */}
      <form
        onSubmit={handleSaveApp}
        className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-5 space-y-3"
      >
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-display font-semibold text-white">
              Open or Add Any App
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Type any app name (e.g. Snapchat, Flipkart, Amazon, Paytm, Netflix, Telegram) to launch it or save it to your launcher.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowSchemeInput((v) => !v)}
            className="text-xs text-cyan-300 hover:text-cyan-200 cursor-pointer"
          >
            {showSchemeInput ? 'Hide custom app scheme' : '+ Custom app scheme'}
          </button>
        </div>

        <div className="flex flex-col sm:flex-row gap-2.5">
          <input
            type="text"
            value={appName}
            onChange={(e) => setAppName(e.target.value)}
            placeholder="App name (e.g. Spotify, Snapchat, Flipkart, Paytm)"
            className="flex-1 min-h-[44px] rounded-full border border-cyan-400/30 bg-[#07182E] px-4 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:border-cyan-300"
          />

          {showSchemeInput && (
            <input
              type="text"
              value={customScheme}
              onChange={(e) => setCustomScheme(e.target.value)}
              placeholder="Optional app scheme (e.g. spotify://)"
              className="flex-1 min-h-[44px] rounded-full border border-cyan-400/30 bg-[#07182E] px-4 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:border-cyan-300"
            />
          )}

          <div className="flex items-center gap-2 shrink-0">
            {resolvedCustomApp ? (
              <a
                href={resolvedCustomApp.url}
                target={isWebProtocol(resolvedCustomApp.url) ? '_blank' : undefined}
                rel={
                  isWebProtocol(resolvedCustomApp.url)
                    ? 'noopener noreferrer'
                    : undefined
                }
                className="min-h-[44px] px-4 rounded-full bg-[#00D4FF] hover:bg-cyan-300 text-sm font-bold text-slate-950 inline-flex items-center justify-center gap-1.5 whitespace-nowrap"
              >
                <ExternalLink className="h-4 w-4" />
                Open App
              </a>
            ) : (
              <span className="min-h-[44px] px-4 rounded-full bg-[#07182E] border border-cyan-400/20 text-sm font-semibold text-slate-500 inline-flex items-center justify-center gap-1.5 whitespace-nowrap select-none">
                <ExternalLink className="h-4 w-4" />
                Open App
              </span>
            )}

            <button
              type="submit"
              className="min-h-[44px] px-4 rounded-full border border-cyan-400/35 bg-[#07182E] hover:bg-[#0B2342] text-sm font-semibold text-cyan-100 inline-flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              Save
            </button>
          </div>
        </div>

        {formError && <p className="text-xs text-amber-400">{formError}</p>}
      </form>
    </div>
  );
};
