import React from 'react';
import { Volume2 } from 'lucide-react';
import type { JarvisSettings } from '../types/jarvis.ts';

interface SettingsPanelProps {
  settings: JarvisSettings;
  onChange: (next: JarvisSettings) => void;
  onTestVoice: () => void;
  onClearHistory: () => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({
  settings,
  onChange,
  onTestVoice,
  onClearHistory,
}) => {
  return (
    <div className="space-y-5">
      <div className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-5 space-y-5">
        <div>
          <h2 className="text-base font-display font-semibold text-white">
            JARVIS Voice &amp; Security Settings
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure bilingual recognition, text-to-speech synthesis, and confirmation safeguards.
          </p>
        </div>

        {/* Language */}
        <div className="flex flex-wrap items-center justify-between gap-3 py-2 border-b border-cyan-400/15">
          <div>
            <div className="text-sm font-medium text-white">
              Speech Recognition Language
            </div>
            <div className="text-xs text-slate-400">
              Switch between Hinglish/Indian English, Hindi, or US English
            </div>
          </div>
          <select
            value={settings.language}
            onChange={(e) =>
              onChange({
                ...settings,
                language: e.target.value as JarvisSettings['language'],
              })
            }
            className="min-h-[44px] rounded-full border border-cyan-400/30 bg-[#07182E] px-4 text-xs font-medium text-white focus:outline-none focus:border-cyan-300"
          >
            <option value="en-IN">English / Hinglish (en-IN)</option>
            <option value="hi-IN">Hindi (hi-IN)</option>
            <option value="en-US">English (en-US)</option>
          </select>
        </div>

        {/* Auto Speak */}
        <div className="flex items-center justify-between gap-4 py-2 border-b border-cyan-400/15">
          <div>
            <div className="text-sm font-medium text-white">
              Voice Output (Text-to-Speech)
            </div>
            <div className="text-xs text-slate-400">
              Automatically read JARVIS responses aloud via SpeechSynthesis
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={settings.autoSpeak}
            onClick={() =>
              onChange({ ...settings, autoSpeak: !settings.autoSpeak })
            }
            className={`w-12 h-7 rounded-full p-1 transition-colors cursor-pointer shrink-0 ${
              settings.autoSpeak ? 'bg-[#00D4FF]' : 'bg-slate-700'
            }`}
          >
            <span
              className={`block h-5 w-5 rounded-full bg-white transition-transform ${
                settings.autoSpeak ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Speech Rate & Pitch */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-2 border-b border-cyan-400/15">
          <div>
            <div className="flex justify-between text-xs text-slate-300 mb-2">
              <span>Speech Speed</span>
              <span className="tabular-nums font-mono">
                {settings.speechRate.toFixed(1)}x
              </span>
            </div>
            <input
              type="range"
              min={0.7}
              max={1.4}
              step={0.1}
              value={settings.speechRate}
              onChange={(e) =>
                onChange({ ...settings, speechRate: Number(e.target.value) })
              }
              className="w-full accent-cyan-400"
            />
          </div>
          <div>
            <div className="flex justify-between text-xs text-slate-300 mb-2">
              <span>Voice Pitch</span>
              <span className="tabular-nums font-mono">
                {settings.speechPitch.toFixed(1)}
              </span>
            </div>
            <input
              type="range"
              min={0.7}
              max={1.3}
              step={0.1}
              value={settings.speechPitch}
              onChange={(e) =>
                onChange({ ...settings, speechPitch: Number(e.target.value) })
              }
              className="w-full accent-cyan-400"
            />
          </div>
        </div>

        {/* Wake Word Mode */}
        <div className="flex items-center justify-between gap-4 py-2 border-b border-cyan-400/15">
          <div>
            <div className="text-sm font-medium text-white">
              Wake-Word Listener (&ldquo;Jarvis&rdquo;)
            </div>
            <div className="text-xs text-slate-400">
              Continuously listens while this browser tab is active and responds when you say &ldquo;Jarvis&rdquo;
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={settings.wakeWordEnabled}
            onClick={() =>
              onChange({
                ...settings,
                wakeWordEnabled: !settings.wakeWordEnabled,
              })
            }
            className={`w-12 h-7 rounded-full p-1 transition-colors cursor-pointer shrink-0 ${
              settings.wakeWordEnabled ? 'bg-[#00D4FF]' : 'bg-slate-700'
            }`}
          >
            <span
              className={`block h-5 w-5 rounded-full bg-white transition-transform ${
                settings.wakeWordEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Confirm Sensitive Actions */}
        <div className="flex items-center justify-between gap-4 py-2 border-b border-cyan-400/15">
          <div>
            <div className="text-sm font-medium text-white">
              Confirm Sensitive Web Actions
            </div>
            <div className="text-xs text-slate-400">
              Always ask before opening camera, screen share, location, or launching apps
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={settings.confirmSensitiveActions}
            onClick={() =>
              onChange({
                ...settings,
                confirmSensitiveActions: !settings.confirmSensitiveActions,
              })
            }
            className={`w-12 h-7 rounded-full p-1 transition-colors cursor-pointer shrink-0 ${
              settings.confirmSensitiveActions ? 'bg-[#00D4FF]' : 'bg-slate-700'
            }`}
          >
            <span
              className={`block h-5 w-5 rounded-full bg-white transition-transform ${
                settings.confirmSensitiveActions
                  ? 'translate-x-5'
                  : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <button
            type="button"
            onClick={onTestVoice}
            className="min-h-[44px] px-4 py-2 rounded-full bg-[#00D4FF] hover:bg-cyan-300 text-xs font-bold text-slate-950 inline-flex items-center gap-2 cursor-pointer"
          >
            <Volume2 className="h-4 w-4" />
            Test JARVIS Voice
          </button>
          <button
            type="button"
            onClick={onClearHistory}
            className="min-h-[44px] px-4 py-2 rounded-full border border-rose-500/40 bg-rose-500/10 hover:bg-rose-500/20 text-xs font-semibold text-rose-200 cursor-pointer"
          >
            Clear Command History
          </button>
        </div>
      </div>

      {/* Browser Security Boundary Note */}
      <div className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-5 space-y-2">
        <h3 className="text-sm font-display font-semibold text-white">
          Browser Sandbox &amp; Deployment Notes
        </h3>
        <p className="text-xs text-slate-400 leading-relaxed">
          JARVIS AI runs natively in modern mobile and desktop browsers as an installable PWA. Sensitive APIs (Camera, Microphone, Location, Screen Share, Clipboard) require explicit user authorization. System-level Android/iOS OS settings (lockscreen unlock, OS Wi-Fi/Bluetooth, SMS inbox) are protected by browser security and will never be faked.
        </p>
      </div>
    </div>
  );
};
