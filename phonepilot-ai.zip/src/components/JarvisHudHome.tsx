import React, { useEffect, useRef, useState } from 'react';
import {
  BarChart3,
  Brain,
  Crown,
  LayoutGrid,
  MessageSquareMore,
  Mic,
  MicOff,
  Play,
  Rocket,
  Square,
  User,
  VolumeX,
  Wifi,
  WifiOff,
  Zap,
} from 'lucide-react';
import type {
  BatterySnapshot,
  JarvisStatus,
  NetworkSnapshot,
} from '../types/jarvis.ts';

interface JarvisHudHomeProps {
  aiStatus: JarvisStatus;
  isListening: boolean;
  isSpeaking: boolean;
  wakeWordEnabled: boolean;
  interimTranscript: string;
  audioStream: MediaStream | null;
  battery: BatterySnapshot;
  network: NetworkSnapshot;
  onToggleListen: () => void;
  onEndSession: () => void;
  onOpenChat: (starterPrompt?: string) => void;
  onOpenSection: (
    section: 'controls' | 'launcher' | 'stats' | 'permissions' | 'settings'
  ) => void;
}

export const JarvisHudHome: React.FC<JarvisHudHomeProps> = ({
  aiStatus,
  isListening,
  isSpeaking,
  wakeWordEnabled,
  interimTranscript,
  audioStream,
  battery,
  network,
  onToggleListen,
  onEndSession,
  onOpenChat,
  onOpenSection,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [portraitError, setPortraitError] = useState(false);

  // Real Web Audio API waveform rendered inside the circular Start Voice core
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId = 0;
    let audioCtx: AudioContext | null = null;
    let analyser: AnalyserNode | null = null;
    let source: MediaStreamAudioSourceNode | null = null;
    let dataArray: Uint8Array<ArrayBuffer> | null = null;

    if (audioStream && isListening) {
      try {
        const AudioContextCtor =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext })
            .webkitAudioContext;
        audioCtx = new AudioContextCtor();
        analyser = audioCtx.createAnalyser();
        analyser.fftSize = 64;
        source = audioCtx.createMediaStreamSource(audioStream);
        source.connect(analyser);
        dataArray = new Uint8Array(new ArrayBuffer(analyser.frequencyBinCount));
      } catch {
        analyser = null;
      }
    }

    let phase = 0;

    const draw = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const barCount = 24;
      const gap = 3;
      const barWidth = (width - gap * (barCount - 1)) / barCount;

      if (analyser && dataArray && isListening) {
        analyser.getByteFrequencyData(dataArray);
        for (let i = 0; i < barCount; i++) {
          const val = dataArray[i % dataArray.length] || 0;
          const barHeight = Math.max(3, (val / 255) * (height - 4));
          const x = i * (barWidth + gap);
          const y = (height - barHeight) / 2;
          ctx.fillStyle = '#38BDF8';
          ctx.fillRect(x, y, barWidth, barHeight);
        }
      } else if (isSpeaking || aiStatus === 'thinking') {
        phase += isSpeaking ? 0.18 : 0.09;
        for (let i = 0; i < barCount; i++) {
          const wave = Math.sin(phase + i * 0.45) * 0.5 + 0.5;
          const barHeight =
            3 + wave * (isSpeaking ? height * 0.72 : height * 0.4);
          const x = i * (barWidth + gap);
          const y = (height - barHeight) / 2;
          ctx.fillStyle = isSpeaking ? '#00D4FF' : 'rgba(56, 189, 248, 0.75)';
          ctx.fillRect(x, y, barWidth, barHeight);
        }
      } else {
        // Subtle symmetric idle HUD waveform silhouette matching screenshot
        for (let i = 0; i < barCount; i++) {
          const distFromCenter =
            1 - Math.abs(i - (barCount - 1) / 2) / ((barCount - 1) / 2);
          const barHeight = Math.max(
            2,
            Math.round(distFromCenter * distFromCenter * (height * 0.55))
          );
          const x = i * (barWidth + gap);
          const y = (height - barHeight) / 2;
          ctx.fillStyle = 'rgba(0, 212, 255, 0.55)';
          ctx.fillRect(x, y, barWidth, barHeight);
        }
      }

      animationId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animationId);
      source?.disconnect();
      if (audioCtx && audioCtx.state !== 'closed') {
        void audioCtx.close();
      }
    };
  }, [audioStream, isListening, isSpeaking, aiStatus]);

  const aiLabel =
    aiStatus === 'idle'
      ? 'Online'
      : aiStatus === 'listening'
      ? 'Listening'
      : aiStatus === 'thinking'
      ? 'Thinking'
      : aiStatus === 'speaking'
      ? 'Speaking'
      : 'Check';

  const featureTiles: Array<{
    id: string;
    title: string;
    subtitle: string;
    icon: React.ComponentType<{ className?: string }>;
    onClick: () => void;
  }> = [
    {
      id: 'ai-chat',
      title: 'AI Chat',
      subtitle: 'Ask Anything',
      icon: MessageSquareMore,
      onClick: () => onOpenChat(),
    },
    {
      id: 'smart-brain',
      title: 'Smart Brain',
      subtitle: 'Get Ideas',
      icon: Brain,
      onClick: () =>
        onOpenChat(
          'Mujhe aaj ke liye 3 smart productivity aur coding ideas do'
        ),
    },
    {
      id: 'boost',
      title: 'Boost',
      subtitle: 'Phone Controls',
      icon: Rocket,
      onClick: () => onOpenSection('controls'),
    },
    {
      id: 'app-hub',
      title: 'App Hub',
      subtitle: 'Launch Apps',
      icon: Play,
      onClick: () => onOpenSection('launcher'),
    },
    {
      id: 'analytics',
      title: 'Analytics',
      subtitle: 'Track Progress',
      icon: BarChart3,
      onClick: () => onOpenSection('stats'),
    },
    {
      id: 'more-options',
      title: 'More Options',
      subtitle: 'Explore More',
      icon: LayoutGrid,
      onClick: () => onOpenSection('permissions'),
    },
  ];

  return (
    <div className="w-full space-y-4">
      {/* Top Hero Stage: Emblem + Glowing Crowned Portrait + Commander Greeting */}
      <div className="relative pt-1">
        <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2 sm:gap-4">
          {/* Left Emblem: Stylized Avengers-A + JARVIS AI ASSISTANT */}
          <div className="flex flex-col items-center justify-center text-center select-none">
            <svg
              viewBox="0 0 80 80"
              className="h-12 w-12 sm:h-14 sm:w-14 drop-shadow-[0_0_12px_rgba(0,212,255,0.65)]"
              aria-hidden="true"
            >
              <circle
                cx="40"
                cy="40"
                r="28"
                fill="none"
                stroke="#00D4FF"
                strokeWidth="4.5"
                strokeDasharray="142 34"
                strokeDashoffset="-12"
              />
              <path
                d="M25 60 L41 16 L51 60 M31 45 H49 L56 41 L49 37"
                fill="none"
                stroke="#00D4FF"
                strokeWidth="5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <div className="mt-1 font-display font-extrabold italic tracking-wider text-sm sm:text-base bg-gradient-to-b from-white via-slate-200 to-cyan-300 bg-clip-text text-transparent">
              JARVIS
            </div>
            <div className="text-[9px] sm:text-[10px] font-semibold tracking-wider text-cyan-200/90">
              AI ASSISTANT
            </div>
          </div>

          {/* Center Glowing Arc Portrait + Golden Crown */}
          <div className="relative flex flex-col items-center">
            <Crown
              className="h-6 w-6 sm:h-7 sm:w-7 text-amber-400 fill-amber-400 drop-shadow-[0_0_10px_rgba(251,191,36,0.75)] -mb-2 z-20"
              aria-hidden="true"
            />
            <div className="relative h-32 w-32 sm:h-36 sm:w-36 flex items-center justify-center">
              {/* Outer HUD rings */}
              <svg
                viewBox="0 0 180 180"
                className={`absolute inset-0 h-full w-full ${
                  isListening || aiStatus === 'thinking'
                    ? 'animate-jarvis-slow'
                    : ''
                }`}
                aria-hidden="true"
              >
                <circle
                  cx="90"
                  cy="90"
                  r="86"
                  fill="none"
                  stroke="rgba(0, 212, 255, 0.25)"
                  strokeWidth="1.5"
                />
                <circle
                  cx="90"
                  cy="90"
                  r="79"
                  fill="none"
                  stroke="#00D4FF"
                  strokeOpacity="0.6"
                  strokeWidth="2"
                  strokeDasharray="42 18 14 18"
                />
              </svg>

              {/* Glowing Cyan Portrait Ring */}
              <div className="relative h-[108px] w-[108px] sm:h-[120px] sm:w-[120px] rounded-full p-[3px] bg-gradient-to-b from-cyan-300 via-sky-400 to-cyan-500 shadow-[0_0_26px_rgba(0,212,255,0.65)]">
                <div className="h-full w-full rounded-full overflow-hidden bg-[#041428] flex items-center justify-center">
                  {!portraitError ? (
                    <img
                      src="/assets/commander_portrait.png"
                      alt="Commander Ayush"
                      referrerPolicy="no-referrer"
                      onError={() => setPortraitError(true)}
                      className="h-full w-full object-cover scale-[1.08]"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-cyan-300">
                      <User className="h-10 w-10" />
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Right Greeting Quote */}
          <div className="text-left pl-1 sm:pl-2">
            <p className="text-xs sm:text-sm italic font-semibold text-white leading-snug">
              &ldquo;Hello,
              <br />
              Commander!&rdquo;
            </p>
            <p className="mt-1.5 text-[11px] sm:text-xs italic text-cyan-100/85 leading-snug">
              I am JARVIS, Your Personal AI Assistant.
            </p>
            <div className="mt-2 h-[1px] w-16 bg-gradient-to-r from-cyan-400/80 to-transparent" />
          </div>
        </div>

        {/* Center Metallic Display Title */}
        <div className="mt-1 text-center">
          <h1 className="text-3xl sm:text-4xl font-display font-extrabold italic tracking-[0.14em] bg-gradient-to-b from-white via-slate-100 to-cyan-300 bg-clip-text text-transparent drop-shadow-[0_2px_14px_rgba(0,212,255,0.3)]">
            JARVIS
          </h1>
          <div className="mt-0.5 flex items-center justify-center gap-2.5 px-4">
            <span className="h-[1px] flex-1 max-w-[64px] bg-gradient-to-r from-transparent to-cyan-400/70" />
            <span className="text-[11px] sm:text-xs font-display font-bold tracking-[0.18em] text-cyan-100">
              SMART AI ASSISTANT
            </span>
            <span className="h-[1px] flex-1 max-w-[64px] bg-gradient-to-l from-transparent to-cyan-400/70" />
          </div>
        </div>
      </div>

      {/* Middle 3-Control HUD Console: Network WiFi | START VOICE Core | STOP End Session */}
      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2 sm:gap-3 pt-1">
        {/* Left HUD Tile: Network / WiFi Status */}
        <button
          type="button"
          onClick={() => onOpenSection('stats')}
          className="hud-chamfer-panel min-h-[120px] sm:min-h-[128px] bg-gradient-to-b from-[#07182E]/95 to-[#030D1D]/95 border border-cyan-400/50 shadow-[inset_0_0_18px_rgba(0,212,255,0.12)] hover:border-cyan-300 px-2.5 py-3 flex flex-col items-center justify-center text-center transition-colors cursor-pointer"
        >
          {network.online ? (
            <Wifi className="h-8 w-8 text-[#00D4FF] drop-shadow-[0_0_10px_rgba(0,212,255,0.7)]" />
          ) : (
            <WifiOff className="h-8 w-8 text-amber-400" />
          )}
          <span className="mt-2 text-xs sm:text-sm font-display font-bold text-white whitespace-nowrap">
            Network WiFi
          </span>
          <span className="mt-1 inline-flex items-center gap-1.5 text-[11px] font-medium text-slate-200 whitespace-nowrap">
            <span
              className={`h-2 w-2 rounded-full ${
                network.online ? 'bg-emerald-400' : 'bg-rose-500'
              }`}
            />
            <span>
              {network.online
                ? network.effectiveType
                  ? `Connected (${network.effectiveType.toUpperCase()})`
                  : 'Connected'
                : 'Not Connected'}
            </span>
          </span>
        </button>

        {/* Center Arc-Reactor: START VOICE + Live Waveform */}
        <div className="relative flex flex-col items-center">
          <button
            type="button"
            onClick={onToggleListen}
            aria-label={isListening ? 'Stop voice recognition' : 'Start voice'}
            aria-pressed={isListening}
            className={`relative h-[144px] w-[144px] sm:h-[154px] sm:w-[154px] rounded-full flex flex-col items-center justify-center p-2 transition-transform active:scale-[0.97] cursor-pointer ${
              isListening
                ? 'bg-radial from-cyan-500/35 via-[#07213E] to-[#031022] border-2 border-cyan-300 shadow-[0_0_34px_rgba(0,212,255,0.75)]'
                : 'bg-radial from-cyan-500/20 via-[#061830] to-[#030C1B] border-2 border-[#00D4FF] shadow-[0_0_26px_rgba(0,212,255,0.48)] hover:shadow-[0_0_34px_rgba(0,212,255,0.7)]'
            }`}
          >
            {/* Inner Concentric HUD Ring */}
            <span
              aria-hidden="true"
              className="pointer-events-none absolute inset-1.5 rounded-full border border-cyan-300/45"
            />
            {isListening ? (
              <MicOff className="h-8 w-8 text-cyan-200 drop-shadow-[0_0_10px_rgba(0,212,255,0.8)]" />
            ) : (
              <Mic className="h-8 w-8 text-white drop-shadow-[0_0_10px_rgba(0,212,255,0.85)]" />
            )}
            <span className="mt-1 text-xs sm:text-sm font-display font-extrabold tracking-wide text-white leading-tight">
              {isListening ? 'LISTENING' : 'START'}
              {!isListening && (
                <>
                  <br />
                  VOICE
                </>
              )}
            </span>

            <canvas
              ref={canvasRef}
              width={110}
              height={22}
              className="mt-1 w-[96px] h-[20px]"
              aria-label="Live voice waveform"
            />
          </button>
        </div>

        {/* Right HUD Tile: STOP / End Session */}
        <button
          type="button"
          onClick={onEndSession}
          className="hud-chamfer-panel min-h-[120px] sm:min-h-[128px] bg-gradient-to-b from-[#260911]/95 to-[#140409]/95 border border-rose-500/75 shadow-[inset_0_0_18px_rgba(244,63,94,0.16)] hover:border-rose-400 px-2.5 py-3 flex flex-col items-center justify-center text-center transition-colors cursor-pointer"
        >
          <div className="h-8 w-8 rounded-lg bg-rose-500 shadow-[0_0_14px_rgba(244,63,94,0.7)] flex items-center justify-center">
            {isSpeaking ? (
              <VolumeX className="h-4 w-4 text-white" />
            ) : (
              <Square className="h-4 w-4 text-rose-100 fill-rose-100" />
            )}
          </div>
          <span className="mt-2 text-xs sm:text-sm font-display font-extrabold tracking-wider text-white whitespace-nowrap">
            STOP
          </span>
          <span className="mt-1 text-[11px] font-medium text-rose-300 whitespace-nowrap">
            End Session
          </span>
        </button>
      </div>

      {/* Live Interim Transcript Banner when listening */}
      {interimTranscript && (
        <div className="rounded-xl border border-cyan-400/50 bg-[#07182E]/90 px-3.5 py-2 text-center text-xs text-cyan-200">
          &ldquo;{interimTranscript}&rdquo;
        </div>
      )}

      {/* Real Telemetry Strip: AI Status | System | Battery */}
      <div className="hud-chamfer-panel border border-cyan-400/45 bg-gradient-to-r from-[#051326]/95 via-[#071C36]/95 to-[#051326]/95 px-3 py-2.5 grid grid-cols-3 divide-x divide-cyan-400/25 text-[11px] sm:text-xs shadow-[0_0_18px_rgba(0,212,255,0.12)]">
        <div className="flex items-center justify-center gap-1.5 pr-1 truncate">
          <span
            className={`h-2 w-2 rounded-full shrink-0 ${
              aiStatus === 'error'
                ? 'bg-amber-400'
                : 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.9)]'
            }`}
          />
          <span className="text-slate-300 truncate">
            AI: <strong className="text-emerald-400 font-semibold">{aiLabel}</strong>
          </span>
        </div>

        <div className="flex items-center justify-center gap-1 px-1 truncate">
          <Zap className="h-3.5 w-3.5 text-cyan-400 shrink-0" />
          <span className="text-slate-300 truncate">
            System:{' '}
            <strong className="text-cyan-300 font-semibold">
              {wakeWordEnabled ? 'Wake' : 'Active'}
            </strong>
          </span>
        </div>

        <div className="flex items-center justify-center gap-1 pl-1 truncate tabular-nums">
          <span className="text-slate-300 truncate">
            Battery:{' '}
            <strong className="text-emerald-400 font-semibold">
              {battery.supported && battery.levelPercent !== null
                ? `${battery.levelPercent}%`
                : 'Web'}
            </strong>
          </span>
        </div>
      </div>

      {/* JARVIS FEATURES 2x3 HUD Grid */}
      <div className="rounded-2xl border border-cyan-400/45 bg-[#041022]/85 p-3 shadow-[0_0_24px_rgba(0,212,255,0.1)]">
        <div className="flex items-center justify-center gap-2.5 mb-3">
          <span className="h-[1px] flex-1 bg-gradient-to-r from-transparent to-cyan-400/50" />
          <h2 className="text-xs sm:text-sm font-display font-bold italic tracking-[0.14em] text-cyan-200 whitespace-nowrap">
            JARVIS FEATURES
          </h2>
          <span className="h-[1px] flex-1 bg-gradient-to-l from-transparent to-cyan-400/50" />
        </div>

        <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
          {featureTiles.map((tile) => {
            const Icon = tile.icon;
            return (
              <button
                key={tile.id}
                type="button"
                onClick={tile.onClick}
                className="min-h-[82px] rounded-xl border border-cyan-400/35 bg-gradient-to-b from-[#081C36]/90 to-[#041020]/95 hover:border-cyan-300 hover:from-[#0B2547] p-2.5 flex flex-col items-center justify-center text-center transition-colors cursor-pointer"
              >
                <Icon className="h-5 w-5 sm:h-6 sm:w-6 text-[#00D4FF] drop-shadow-[0_0_8px_rgba(0,212,255,0.65)]" />
                <span className="mt-1.5 text-[11px] sm:text-xs font-display font-semibold text-white leading-tight">
                  {tile.title}
                </span>
                <span className="mt-0.5 text-[10px] text-slate-400 leading-tight truncate max-w-full">
                  {tile.subtitle}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
