import React, { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  Camera,
  Check,
  ExternalLink,
  History,
  LayoutGrid,
  Mic,
  MicOff,
  Paperclip,
  Plus,
  Sliders,
  Volume2,
  X,
} from 'lucide-react';
import type {
  ChatMessage,
  CommandHistoryEntry,
  JarvisActionCard,
  ProposedAppLaunch,
  ProposedBrowserAction,
} from '../types/jarvis.ts';

interface AssistantChatPanelProps {
  messages: ChatMessage[];
  historyLog: CommandHistoryEntry[];
  isThinking: boolean;
  isListening: boolean;
  interimTranscript: string;
  attachedFileName: string | null;
  subView: 'chat' | 'history';
  onChangeSubView: (view: 'chat' | 'history') => void;
  onClearAttachment: () => void;
  onAttachFile: (file: {
    name: string;
    mimeType: string;
    base64Data?: string;
    textContent?: string;
  }) => void;
  onSendMessage: (
    text: string,
    source?: 'voice' | 'text' | 'wake_word'
  ) => Promise<void>;
  onToggleVoiceCommand: () => void;
  onNavigateSection: (section: 'controls' | 'launcher' | 'camera') => void;
  onConfirmBrowserAction: (
    messageId: string,
    action: ProposedBrowserAction
  ) => Promise<void>;
  onDeclineAction: (messageId: string, actionId: string) => void;
  onMarkAppLaunched: (messageId: string, action: ProposedAppLaunch) => void;
  onSpeakMessage: (text: string) => void;
}

const SUGGESTED_PROMPTS = [
  'YouTube par lo-fi music search karo',
  'Instagram open karo',
  'WhatsApp kholo',
  'Mera camera open karo',
  'Spotify app open karo',
];

export const AssistantChatPanel: React.FC<AssistantChatPanelProps> = ({
  messages,
  historyLog,
  isThinking,
  isListening,
  interimTranscript,
  attachedFileName,
  subView,
  onChangeSubView,
  onClearAttachment,
  onAttachFile,
  onSendMessage,
  onToggleVoiceCommand,
  onNavigateSection,
  onConfirmBrowserAction,
  onDeclineAction,
  onMarkAppLaunched,
  onSpeakMessage,
}) => {
  const [input, setInput] = useState('');
  const [showPlusMenu, setShowPlusMenu] = useState(false);
  const [showScrollButton, setShowScrollButton] = useState(false);

  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    bottomRef.current?.scrollIntoView({ behavior });
  };

  useEffect(() => {
    if (subView === 'chat') {
      scrollToBottom(isThinking ? 'auto' : 'smooth');
    }
  }, [messages, isThinking, subView]);

  const handleScroll = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const distFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    setShowScrollButton(distFromBottom > 120);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || isThinking) return;
    setInput('');
    setShowPlusMenu(false);
    await onSendMessage(trimmed, 'text');
  };

  const handleFilePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setShowPlusMenu(false);

    if (file.type.startsWith('image/') && file.size <= 4 * 1024 * 1024) {
      const reader = new FileReader();
      reader.onload = () => {
        const res = String(reader.result || '');
        const base64 = res.split(',')[1] || '';
        onAttachFile({
          name: file.name,
          mimeType: file.type,
          base64Data: base64,
        });
      };
      reader.readAsDataURL(file);
    } else if (
      (file.type.startsWith('text/') ||
        /\.(txt|md|json|csv|js|ts|py|html)$/i.test(file.name)) &&
      file.size <= 512 * 1024
    ) {
      const reader = new FileReader();
      reader.onload = () => {
        onAttachFile({
          name: file.name,
          mimeType: file.type || 'text/plain',
          textContent: String(reader.result || ''),
        });
      };
      reader.readAsText(file);
    }
    e.target.value = '';
  };

  if (subView === 'history') {
    return (
      <section className="flex flex-col rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-4 sm:p-5 h-full min-h-[420px]">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <History className="h-4 w-4 text-cyan-400" />
            <h2 className="text-base font-display font-semibold text-white">
              Command History ({historyLog.length})
            </h2>
          </div>
          <button
            type="button"
            onClick={() => onChangeSubView('chat')}
            className="min-h-[38px] px-3.5 rounded-full bg-[#07182E] border border-cyan-400/40 text-xs font-medium text-cyan-100 hover:bg-cyan-500/20 cursor-pointer"
          >
            Back to AI Chat
          </button>
        </div>

        <div className="rounded-xl bg-[#020A17] border border-cyan-400/25 divide-y divide-cyan-400/15 overflow-y-auto thin-scrollbar flex-1">
          {historyLog.length === 0 ? (
            <div className="py-16 px-6 text-center">
              <p className="text-sm font-medium text-slate-200">
                No commands recorded yet
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Speak or type a command in AI Chat to log activity.
              </p>
            </div>
          ) : (
            historyLog.map((entry) => (
              <div
                key={entry.id}
                className="px-4 py-3.5 flex items-start justify-between gap-4 hover:bg-cyan-500/5"
              >
                <div className="min-w-0">
                  <div className="text-sm font-medium text-white">
                    {entry.command}
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    {entry.source.replace('_', ' ')} · {entry.outcome}
                  </div>
                </div>
                <span className="text-xs text-cyan-300/75 tabular-nums shrink-0">
                  {entry.timestamp}
                </span>
              </div>
            ))
          )}
        </div>
      </section>
    );
  }

  return (
    <section className="relative flex flex-col h-full min-h-[460px] rounded-2xl border border-cyan-400/35 bg-[#041022]/90 shadow-[0_0_24px_rgba(0,212,255,0.08)] overflow-hidden">
      <input
        ref={fileInputRef}
        type="file"
        onChange={handleFilePick}
        className="hidden"
      />

      {/* Compact Chat Header Strip */}
      <div className="px-4 py-3 border-b border-cyan-400/20 bg-[#051429]/90 flex items-center justify-between gap-3">
        <div className="min-w-0">
          <h2 className="text-sm font-display font-bold tracking-wide text-white">
            JARVIS AI Chat
          </h2>
          <p className="text-[11px] text-cyan-200/75 truncate">
            Hindi, Hinglish &amp; English voice or text assistant
          </p>
        </div>
        <button
          type="button"
          onClick={() => onChangeSubView('history')}
          className="min-h-[36px] px-3 rounded-full border border-cyan-400/35 bg-[#071A33] hover:bg-cyan-500/20 text-xs font-medium text-cyan-100 inline-flex items-center gap-1.5 shrink-0 cursor-pointer"
        >
          <History className="h-3.5 w-3.5 text-cyan-400" />
          <span>History ({historyLog.length})</span>
        </button>
      </div>

      {/* Scrollable Conversation Feed */}
      <div
        ref={scrollContainerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto thin-scrollbar px-4 py-4 space-y-5"
      >
        {messages.map((msg) => {
          if (msg.role === 'user') {
            return (
              <div key={msg.id} className="flex flex-col items-end">
                <div className="max-w-[85%] sm:max-w-[75%] rounded-2xl border border-cyan-400/35 bg-[#0A2342] px-4 py-2.5 text-[14px] leading-relaxed text-white shadow-sm">
                  {msg.attachmentName && (
                    <div className="text-xs text-cyan-300 mb-1 flex items-center gap-1">
                      <Paperclip className="h-3 w-3" />
                      <span>{msg.attachmentName}</span>
                    </div>
                  )}
                  <p className="whitespace-pre-wrap">{msg.text}</p>
                </div>
              </div>
            );
          }

          return (
            <div key={msg.id} className="flex flex-col items-start">
              <div
                className={`w-full text-[14px] leading-7 ${
                  msg.error
                    ? 'rounded-2xl bg-amber-950/40 border border-amber-500/40 px-4 py-3 text-amber-200'
                    : 'text-slate-100'
                }`}
              >
                <p className="whitespace-pre-wrap">{msg.text}</p>

                {/* Action / App Launch Cards */}
                {msg.actions && msg.actions.length > 0 && (
                  <div className="mt-3 space-y-2.5 max-w-md">
                    {msg.actions.map((act: JarvisActionCard) => {
                      if (act.kind === 'app_launch') {
                        return (
                          <div
                            key={act.id}
                            className="rounded-xl border border-cyan-400/35 bg-[#07182E] p-3.5 flex items-center justify-between gap-3"
                          >
                            <div className="min-w-0">
                              <div className="text-sm font-semibold text-white">
                                Open {act.appName}
                              </div>
                              <div className="text-xs text-slate-300 truncate max-w-[230px]">
                                {act.description}
                              </div>
                            </div>
                            {act.status === 'pending' ? (
                              <div className="flex items-center gap-2 shrink-0">
                                <button
                                  type="button"
                                  onClick={() =>
                                    onDeclineAction(msg.id, act.id)
                                  }
                                  className="min-h-[38px] px-3 rounded-full border border-cyan-400/30 text-xs text-slate-300 hover:bg-white/10 cursor-pointer"
                                >
                                  Cancel
                                </button>
                                <a
                                  href={act.url}
                                  target={
                                    act.url.startsWith('http')
                                      ? '_blank'
                                      : undefined
                                  }
                                  rel={
                                    act.url.startsWith('http')
                                      ? 'noopener noreferrer'
                                      : undefined
                                  }
                                  onClick={() =>
                                    onMarkAppLaunched(msg.id, act)
                                  }
                                  className="min-h-[38px] px-3.5 rounded-full bg-cyan-500 hover:bg-cyan-400 text-xs font-bold text-slate-950 inline-flex items-center gap-1"
                                >
                                  <span>Launch</span>
                                  <ExternalLink className="h-3 w-3" />
                                </a>
                              </div>
                            ) : (
                              <span className="text-xs font-medium text-cyan-300 capitalize">
                                {act.status}
                              </span>
                            )}
                          </div>
                        );
                      }

                      return (
                        <div
                          key={act.id}
                          className="rounded-xl border border-cyan-400/35 bg-[#07182E] p-3.5 space-y-2.5"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="min-w-0">
                              <div className="text-sm font-semibold text-white">
                                {act.label}
                              </div>
                              <div className="text-xs text-slate-300">
                                {act.description}
                              </div>
                            </div>

                            {act.status === 'pending' && (
                              <div className="flex items-center gap-2 shrink-0">
                                <button
                                  type="button"
                                  onClick={() =>
                                    onDeclineAction(msg.id, act.id)
                                  }
                                  className="min-h-[38px] px-3 rounded-full border border-cyan-400/30 text-xs text-slate-300 hover:bg-white/10 inline-flex items-center gap-1 cursor-pointer"
                                >
                                  <X className="h-3 w-3" />
                                  Cancel
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    onConfirmBrowserAction(msg.id, act)
                                  }
                                  className="min-h-[38px] px-3.5 rounded-full bg-cyan-500 hover:bg-cyan-400 text-xs font-bold text-slate-950 inline-flex items-center gap-1 cursor-pointer"
                                >
                                  <Check className="h-3 w-3" />
                                  {act.requiresConfirmation
                                    ? 'Authorize'
                                    : 'Run'}
                                </button>
                              </div>
                            )}
                          </div>

                          {act.resultMessage && (
                            <div
                              className={`text-xs flex items-center gap-1.5 ${
                                act.status === 'unsupported'
                                  ? 'text-amber-300'
                                  : 'text-emerald-400'
                              }`}
                            >
                              {act.status === 'unsupported' ? (
                                <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                              ) : (
                                <Check className="h-3.5 w-3.5 shrink-0" />
                              )}
                              <span>{act.resultMessage}</span>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}

                {!msg.error && (
                  <div className="mt-1.5 flex items-center gap-3 text-[11px] text-slate-400 tabular-nums">
                    <span>{msg.timestamp}</span>
                    <button
                      type="button"
                      onClick={() => onSpeakMessage(msg.text)}
                      title="Speak response"
                      aria-label="Speak response"
                      className="p-1 text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer"
                    >
                      <Volume2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {isThinking && messages[messages.length - 1]?.role === 'user' && (
          <div className="flex items-center gap-2 text-sm text-cyan-300">
            <span className="h-2.5 w-2.5 rounded-full bg-cyan-400" />
            <span>JARVIS is thinking...</span>
          </div>
        )}

        {messages.length <= 1 && (
          <div className="pt-2 flex flex-wrap gap-2">
            {SUGGESTED_PROMPTS.map((prompt) => (
              <button
                key={prompt}
                type="button"
                disabled={isThinking}
                onClick={() => onSendMessage(prompt, 'text')}
                className="min-h-[38px] px-3.5 py-1.5 rounded-full bg-[#07182E] border border-cyan-400/30 hover:border-cyan-300 text-xs text-cyan-100 transition-colors cursor-pointer disabled:opacity-50"
              >
                {prompt}
              </button>
            ))}
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Scroll-To-Bottom Floating Button inside panel */}
      {showScrollButton && (
        <button
          type="button"
          onClick={() => scrollToBottom('smooth')}
          aria-label="Scroll to latest message"
          className="absolute bottom-20 left-1/2 -translate-x-1/2 z-10 h-9 w-9 rounded-full bg-[#08203E] border border-cyan-400/50 shadow-lg flex items-center justify-center text-cyan-100 hover:bg-cyan-500/20 cursor-pointer"
        >
          <ArrowDown className="h-4 w-4" />
        </button>
      )}

      {/* Docked HUD Composer Bar */}
      <div className="p-3 border-t border-cyan-400/20 bg-[#051226]/95 space-y-2">
        {(isListening || interimTranscript) && (
          <div className="px-3.5 py-2 rounded-xl bg-[#08203E] border border-cyan-400/50 text-xs text-cyan-100 flex items-center justify-between gap-3">
            <span className="truncate">
              {interimTranscript
                ? `"${interimTranscript}"`
                : 'Listening... speak in Hindi, Hinglish, or English'}
            </span>
            <button
              type="button"
              onClick={onToggleVoiceCommand}
              className="text-rose-400 font-semibold shrink-0 cursor-pointer"
            >
              Stop
            </button>
          </div>
        )}

        {attachedFileName && (
          <div className="flex items-center justify-between px-3.5 py-2 rounded-xl bg-[#08203E] border border-cyan-400/30 text-xs text-cyan-100">
            <span className="truncate inline-flex items-center gap-1.5">
              <Paperclip className="h-3.5 w-3.5 text-cyan-400" />
              {attachedFileName}
            </span>
            <button
              type="button"
              onClick={onClearAttachment}
              className="text-slate-300 hover:text-white cursor-pointer"
            >
              Remove
            </button>
          </div>
        )}

        {showPlusMenu && (
          <div className="rounded-xl bg-[#07182E] border border-cyan-400/35 p-2 grid grid-cols-2 sm:grid-cols-4 gap-1.5 shadow-xl">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="min-h-[42px] px-3 rounded-lg hover:bg-cyan-500/15 text-xs font-medium text-cyan-100 inline-flex items-center gap-2 cursor-pointer"
            >
              <Paperclip className="h-4 w-4 text-cyan-400" />
              Attach File
            </button>
            <button
              type="button"
              onClick={() => {
                setShowPlusMenu(false);
                onNavigateSection('camera');
              }}
              className="min-h-[42px] px-3 rounded-lg hover:bg-cyan-500/15 text-xs font-medium text-cyan-100 inline-flex items-center gap-2 cursor-pointer"
            >
              <Camera className="h-4 w-4 text-cyan-400" />
              Open Camera
            </button>
            <button
              type="button"
              onClick={() => {
                setShowPlusMenu(false);
                onNavigateSection('launcher');
              }}
              className="min-h-[42px] px-3 rounded-lg hover:bg-cyan-500/15 text-xs font-medium text-cyan-100 inline-flex items-center gap-2 cursor-pointer"
            >
              <LayoutGrid className="h-4 w-4 text-cyan-400" />
              App Launcher
            </button>
            <button
              type="button"
              onClick={() => {
                setShowPlusMenu(false);
                onNavigateSection('controls');
              }}
              className="min-h-[42px] px-3 rounded-lg hover:bg-cyan-500/15 text-xs font-medium text-cyan-100 inline-flex items-center gap-2 cursor-pointer"
            >
              <Sliders className="h-4 w-4 text-cyan-400" />
              Phone Controls
            </button>
          </div>
        )}

        <form
          onSubmit={handleSubmit}
          className="rounded-full bg-[#07182E] border border-cyan-400/40 px-2 py-1.5 flex items-center gap-1.5"
        >
          <button
            type="button"
            onClick={() => setShowPlusMenu((v) => !v)}
            aria-label="Quick actions and attachments"
            className="h-10 w-10 rounded-full hover:bg-cyan-500/15 flex items-center justify-center text-cyan-200 shrink-0 cursor-pointer"
          >
            {showPlusMenu ? (
              <X className="h-5 w-5" />
            ) : (
              <Plus className="h-5 w-5" />
            )}
          </button>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Command JARVIS (Hindi / English)..."
            className="flex-1 min-w-0 min-h-[40px] bg-transparent px-1.5 text-sm text-white placeholder:text-slate-400 focus:outline-none"
          />

          <button
            type="button"
            onClick={onToggleVoiceCommand}
            disabled={isThinking && !isListening}
            aria-label={isListening ? 'Stop listening' : 'Voice command'}
            className={`h-10 w-10 rounded-full flex items-center justify-center shrink-0 transition-colors cursor-pointer disabled:opacity-40 ${
              isListening
                ? 'bg-rose-600 text-white'
                : 'text-cyan-300 hover:bg-cyan-500/15'
            }`}
          >
            {isListening ? (
              <MicOff className="h-5 w-5" />
            ) : (
              <Mic className="h-5 w-5" />
            )}
          </button>

          <button
            type="submit"
            disabled={!input.trim() || isThinking}
            aria-label="Send message"
            className="h-10 w-10 rounded-full bg-[#00D4FF] hover:bg-cyan-300 disabled:opacity-40 text-slate-950 flex items-center justify-center shrink-0 transition-colors cursor-pointer"
          >
            <ArrowUp className="h-5 w-5" />
          </button>
        </form>
      </div>
    </section>
  );
};
