import { useCallback, useEffect, useRef, useState } from 'react';
import {
  BarChart3,
  Crown,
  History,
  Home,
  LayoutGrid,
  Menu,
  MessageSquareMore,
  Settings,
  ShieldCheck,
  Sliders,
  SquarePen,
  User,
  X,
} from 'lucide-react';
import type {
  AppShortcut,
  BatterySnapshot,
  ChatMessage,
  CommandHistoryEntry,
  JarvisSettings,
  JarvisStatus,
  PermissionMatrix,
  PermissionStateValue,
  ProposedAppLaunch,
  ProposedBrowserAction,
  WeatherData,
} from './types/jarvis.ts';
import { useNetworkStatus } from './hooks/useOnlineStatus.ts';
import { PWAInstallButton } from './components/PWAInstallButton.tsx';
import { OfflineIndicator } from './components/OfflineIndicator.tsx';
import { JarvisHudHome } from './components/JarvisHudHome.tsx';
import { SmartDashboard } from './components/SmartDashboard.tsx';
import { AssistantChatPanel } from './components/AssistantChatPanel.tsx';
import { WebControlsPanel } from './components/WebControlsPanel.tsx';
import { AppLauncherPanel } from './components/AppLauncherPanel.tsx';
import { PermissionManager } from './components/PermissionManager.tsx';
import { SettingsPanel } from './components/SettingsPanel.tsx';

type ActiveSection =
  | 'home'
  | 'stats'
  | 'assistant'
  | 'profile'
  | 'controls'
  | 'launcher'
  | 'permissions'
  | 'settings';

interface SpeechRecognitionResultItem {
  isFinal: boolean;
  0: { transcript: string };
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: ArrayLike<SpeechRecognitionResultItem>;
}

interface SpeechRecognitionErrorEventLike {
  error: string;
}

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

interface BatteryManagerLike extends EventTarget {
  level: number;
  charging: boolean;
}

const DEFAULT_SHORTCUTS: AppShortcut[] = [
  { id: 'youtube', name: 'YouTube', url: 'https://www.youtube.com', subtitle: 'Video & Search App', category: 'media' },
  { id: 'instagram', name: 'Instagram', url: 'https://www.instagram.com', subtitle: 'Social & Reels App', category: 'social' },
  { id: 'whatsapp', name: 'WhatsApp', url: 'https://wa.me/', subtitle: 'Messaging App', category: 'social' },
  { id: 'google', name: 'Google', url: 'https://www.google.com', subtitle: 'Search App', category: 'utility' },
  { id: 'maps', name: 'Google Maps', url: 'https://maps.google.com', subtitle: 'Navigation App', category: 'utility' },
  { id: 'spotify', name: 'Spotify', url: 'https://open.spotify.com', subtitle: 'Music App', category: 'media' },
  { id: 'phone', name: 'Phone Dialer', url: 'tel:', subtitle: 'System Dialer', category: 'utility' },
  { id: 'messages', name: 'Messages', url: 'sms:', subtitle: 'System SMS App', category: 'social' },
];

const SHORTCUTS_STORAGE_KEY = 'jarvis_custom_shortcuts_v1';
const SETTINGS_STORAGE_KEY = 'jarvis_settings_v1';

function formatTimeNow(): string {
  return new Date().toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });
}

const WELCOME_MESSAGE: ChatMessage = {
  id: 'jarvis-welcome',
  role: 'assistant',
  timestamp: 'Ready',
  text: 'JARVIS online. Speak or type in Hindi, Hinglish, or English to launch apps (YouTube with search, Instagram, WhatsApp, Google, Camera, or other apps) and control supported browser features.',
};

export default function App() {
  const [activeSection, setActiveSection] = useState<ActiveSection>('home');
  const [assistantSubView, setAssistantSubView] = useState<'chat' | 'history'>('chat');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [aiStatus, setAiStatus] = useState<JarvisStatus>('idle');
  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME_MESSAGE]);
  const [historyLog, setHistoryLog] = useState<CommandHistoryEntry[]>([]);

  const [settings, setSettings] = useState<JarvisSettings>(() => {
    try {
      const saved = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (saved) return JSON.parse(saved) as JarvisSettings;
    } catch {
      // Ignore storage failure
    }
    return {
      language: 'en-IN',
      autoSpeak: true,
      speechRate: 1.0,
      speechPitch: 1.0,
      wakeWordEnabled: false,
      confirmSensitiveActions: true,
    };
  });

  const [shortcuts, setShortcuts] = useState<AppShortcut[]>(() => {
    try {
      const saved = localStorage.getItem(SHORTCUTS_STORAGE_KEY);
      if (saved) {
        const custom = JSON.parse(saved) as AppShortcut[];
        return [...DEFAULT_SHORTCUTS, ...custom];
      }
    } catch {
      // Ignore storage failure
    }
    return DEFAULT_SHORTCUTS;
  });

  const [battery, setBattery] = useState<BatterySnapshot>({
    supported: false,
    levelPercent: null,
    charging: null,
  });
  const network = useNetworkStatus();

  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [weatherLoading, setWeatherLoading] = useState(false);
  const [weatherError, setWeatherError] = useState<string | null>(null);

  const [permissions, setPermissions] = useState<PermissionMatrix>({
    microphone: 'unknown',
    camera: 'unknown',
    geolocation: 'unknown',
    clipboardRead: 'unknown',
    notifications: 'unknown',
    speechRecognition: false,
    speechSynthesis: false,
    batteryApi: false,
    vibrationApi: false,
    fullscreenApi: false,
    screenShareApi: false,
  });

  // Active media & voice states
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [micStream, setMicStream] = useState<MediaStream | null>(null);

  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [torchOn, setTorchOn] = useState(false);
  const [torchSupported, setTorchSupported] = useState<boolean | null>(null);

  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [screenError, setScreenError] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const [attachedFile, setAttachedFile] = useState<{
    name: string;
    mimeType: string;
    base64Data?: string;
    textContent?: string;
  } | null>(null);

  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const wakeRecognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const activeMicStreamRef = useRef<MediaStream | null>(null);
  const finalTranscriptRef = useRef('');
  const sentSpeechRef = useRef(false);
  const settingsRef = useRef(settings);

  useEffect(() => {
    settingsRef.current = settings;
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    } catch {
      // Ignore storage failure
    }
  }, [settings]);

  const refreshPermissions = useCallback(async () => {
    const win = window as unknown as {
      SpeechRecognition?: unknown;
      webkitSpeechRecognition?: unknown;
    };

    const queryPerm = async (name: string): Promise<PermissionStateValue> => {
      if (!navigator.permissions?.query) return 'unknown';
      try {
        const res = await navigator.permissions.query({
          name: name as PermissionName,
        });
        return res.state as PermissionStateValue;
      } catch {
        return 'unknown';
      }
    };

    const [mic, cam, geo, clip] = await Promise.all([
      queryPerm('microphone'),
      queryPerm('camera'),
      queryPerm('geolocation'),
      queryPerm('clipboard-read'),
    ]);

    const notifPerm: PermissionStateValue =
      typeof Notification === 'undefined'
        ? 'unsupported'
        : Notification.permission === 'default'
        ? 'prompt'
        : (Notification.permission as PermissionStateValue);

    setPermissions({
      microphone: mic,
      camera: cam,
      geolocation: geo,
      clipboardRead: clip,
      notifications: notifPerm,
      speechRecognition: Boolean(
        win.SpeechRecognition || win.webkitSpeechRecognition
      ),
      speechSynthesis: 'speechSynthesis' in window,
      batteryApi: 'getBattery' in navigator,
      vibrationApi: 'vibrate' in navigator,
      fullscreenApi: Boolean(document.documentElement.requestFullscreen),
      screenShareApi: Boolean(navigator.mediaDevices?.getDisplayMedia),
    });
  }, []);

  // Battery API + Permission probe + Fullscreen listener
  useEffect(() => {
    void refreshPermissions();

    const nav = navigator as unknown as {
      getBattery?: () => Promise<BatteryManagerLike>;
    };
    let batteryObj: BatteryManagerLike | null = null;
    const updateBattery = () => {
      if (!batteryObj) return;
      setBattery({
        supported: true,
        levelPercent: Math.round(batteryObj.level * 100),
        charging: batteryObj.charging,
      });
    };

    if (nav.getBattery) {
      nav
        .getBattery()
        .then((bm) => {
          batteryObj = bm;
          updateBattery();
          bm.addEventListener('levelchange', updateBattery);
          bm.addEventListener('chargingchange', updateBattery);
        })
        .catch(() => {
          setBattery({ supported: false, levelPercent: null, charging: null });
        });
    }

    const onFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', onFsChange);

    return () => {
      document.removeEventListener('fullscreenchange', onFsChange);
      if (batteryObj) {
        batteryObj.removeEventListener('levelchange', updateBattery);
        batteryObj.removeEventListener('chargingchange', updateBattery);
      }
    };
  }, [refreshPermissions]);

  // Warm up SpeechSynthesis voices + cleanup active streams on unmount
  useEffect(() => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.getVoices();
    }
    return () => {
      recognitionRef.current?.abort();
      wakeRecognitionRef.current?.abort();
      activeMicStreamRef.current?.getTracks().forEach((t) => t.stop());
      micStream?.getTracks().forEach((t) => t.stop());
      cameraStream?.getTracks().forEach((t) => t.stop());
      screenStream?.getTracks().forEach((t) => t.stop());
      window.speechSynthesis?.cancel();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const speakText = useCallback((text: string) => {
    if (!('speechSynthesis' in window) || !text.trim()) return;
    window.speechSynthesis.cancel();

    const cleanText = text.replace(/[*_`#]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    const hasDevanagari = /[\u0900-\u097F]/.test(cleanText);
    utterance.lang = hasDevanagari ? 'hi-IN' : settingsRef.current.language;
    utterance.rate = settingsRef.current.speechRate;
    utterance.pitch = settingsRef.current.speechPitch;

    const voices = window.speechSynthesis.getVoices();
    const matchedVoice = voices.find((v) =>
      v.lang.toLowerCase().startsWith(utterance.lang.split('-')[0].toLowerCase())
    );
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    utterance.onstart = () => {
      setIsSpeaking(true);
      setAiStatus('speaking');
    };
    utterance.onend = () => {
      setIsSpeaking(false);
      setAiStatus('idle');
    };
    utterance.onerror = () => {
      setIsSpeaking(false);
      setAiStatus('idle');
    };

    window.speechSynthesis.speak(utterance);
  }, []);

  const stopSpeaking = () => {
    window.speechSynthesis?.cancel();
    setIsSpeaking(false);
    setAiStatus('idle');
  };

  // Real Browser Actions
  const fetchWeatherWithLocation = useCallback(async (): Promise<string> => {
    if (!navigator.geolocation) {
      const msg = 'Geolocation API is not supported in this browser.';
      setWeatherError(msg);
      return msg;
    }
    setWeatherLoading(true);
    setWeatherError(null);

    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          try {
            const lat = pos.coords.latitude;
            const lon = pos.coords.longitude;
            const res = await fetch(
              `/api/weather?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(
                lon
              )}`
            );
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Weather error');
            setWeather(data as WeatherData);
            void refreshPermissions();
            setWeatherLoading(false);
            resolve(
              `Weather updated: ${data.temperatureC}°C, ${data.condition}, humidity ${data.humidity}%.`
            );
          } catch (err) {
            const msg =
              err instanceof Error ? err.message : 'Unable to fetch weather.';
            setWeatherError(msg);
            setWeatherLoading(false);
            resolve(msg);
          }
        },
        (err) => {
          const msg =
            err.code === err.PERMISSION_DENIED
              ? 'Location permission denied.'
              : 'Unable to retrieve your location.';
          setWeatherError(msg);
          setWeatherLoading(false);
          void refreshPermissions();
          resolve(msg);
        },
        { timeout: 10000 }
      );
    });
  }, [refreshPermissions]);

  const startCamera = useCallback(
    async (facingMode: 'environment' | 'user' = 'environment') => {
      setCameraError(null);
      if (!navigator.mediaDevices?.getUserMedia) {
        setCameraError('Camera API is unavailable in this browser.');
        return;
      }
      cameraStream?.getTracks().forEach((t) => t.stop());

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode },
          audio: false,
        });
        setCameraStream(stream);
        setTorchOn(false);
        const track = stream.getVideoTracks()[0];
        const caps = track?.getCapabilities
          ? (track.getCapabilities() as MediaTrackCapabilities & {
              torch?: boolean;
            })
          : null;
        setTorchSupported(Boolean(caps && 'torch' in caps && caps.torch));
        void refreshPermissions();
      } catch (err) {
        const msg =
          err instanceof Error
            ? `Camera access error: ${err.message}`
            : 'Camera permission denied.';
        setCameraError(msg);
        void refreshPermissions();
      }
    },
    [cameraStream, refreshPermissions]
  );

  const stopCamera = useCallback(() => {
    cameraStream?.getTracks().forEach((t) => t.stop());
    setCameraStream(null);
    setTorchOn(false);
    setTorchSupported(null);
  }, [cameraStream]);

  const toggleTorch = useCallback(async () => {
    if (!cameraStream) {
      await startCamera('environment');
      return;
    }
    const track = cameraStream.getVideoTracks()[0];
    if (!track) return;
    const caps = track.getCapabilities
      ? (track.getCapabilities() as MediaTrackCapabilities & { torch?: boolean })
      : null;

    if (!caps || !('torch' in caps) || !caps.torch) {
      setTorchSupported(false);
      setCameraError(
        'Flashlight (torch) hardware control is not supported on this device or browser.'
      );
      return;
    }

    try {
      const next = !torchOn;
      await track.applyConstraints({
        advanced: [{ torch: next } as MediaTrackConstraintSet],
      });
      setTorchSupported(true);
      setTorchOn(next);
      setCameraError(null);
    } catch {
      setTorchSupported(false);
      setCameraError('Browser blocked hardware torch constraint.');
    }
  }, [cameraStream, startCamera, torchOn]);

  const startScreenShare = useCallback(async () => {
    setScreenError(null);
    if (!navigator.mediaDevices?.getDisplayMedia) {
      setScreenError(
        'Screen sharing (getDisplayMedia) is not supported on this browser.'
      );
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
      });
      stream.getVideoTracks()[0]?.addEventListener('ended', () => {
        setScreenStream(null);
      });
      setScreenStream(stream);
    } catch (err) {
      setScreenError(
        err instanceof Error
          ? err.message
          : 'Screen share authorization cancelled.'
      );
    }
  }, []);

  const stopScreenShare = useCallback(() => {
    screenStream?.getTracks().forEach((t) => t.stop());
    setScreenStream(null);
  }, [screenStream]);

  const toggleFullscreen = useCallback(async (): Promise<string> => {
    if (!document.documentElement.requestFullscreen) {
      return 'Fullscreen API is not supported in this browser.';
    }
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
        return 'Exited fullscreen mode.';
      }
      await document.documentElement.requestFullscreen();
      return 'Entered fullscreen mode.';
    } catch (err) {
      return err instanceof Error
        ? `Fullscreen blocked: ${err.message}`
        : 'Fullscreen request blocked.';
    }
  }, []);

  const triggerVibration = useCallback((): string => {
    if (!('vibrate' in navigator)) {
      return 'Vibration API is unavailable on this browser/device.';
    }
    const ok = navigator.vibrate([120, 60, 120]);
    return ok
      ? 'Triggered device vibration pulse.'
      : 'Vibration was ignored by device settings.';
  }, []);

  const copyClipboard = useCallback(async (text: string): Promise<string> => {
    if (!navigator.clipboard?.writeText) {
      return 'Clipboard write API unavailable.';
    }
    try {
      await navigator.clipboard.writeText(text);
      return `Copied "${text}" to clipboard.`;
    } catch {
      return 'Clipboard write permission denied.';
    }
  }, []);

  const readClipboard = useCallback(async (): Promise<{
    ok: boolean;
    value: string;
  }> => {
    if (!navigator.clipboard?.readText) {
      return { ok: false, value: 'Clipboard read API unavailable.' };
    }
    try {
      const text = await navigator.clipboard.readText();
      void refreshPermissions();
      return { ok: true, value: text || '(Clipboard is empty)' };
    } catch {
      void refreshPermissions();
      return {
        ok: false,
        value: 'Clipboard read permission denied by browser.',
      };
    }
  }, [refreshPermissions]);

  // Send command to Gemini Brain (SSE streaming for instant token rendering)
  const sendToJarvis = useCallback(
    async (
      text: string,
      source: 'voice' | 'text' | 'wake_word' = 'text'
    ) => {
      const userMsg: ChatMessage = {
        id: `u-${Date.now()}`,
        role: 'user',
        text,
        timestamp: formatTimeNow(),
        attachmentName: attachedFile?.name,
      };

      const historyPayload = messages
        .filter((m) => !m.error && m.text.trim())
        .slice(-6)
        .map((m) => ({
          role: m.role,
          text: m.text,
        }));

      setMessages((prev) => [...prev, userMsg]);
      setAiStatus('thinking');
      if (source !== 'text') {
        setActiveSection('assistant');
      }

      const currentAttachment = attachedFile;
      setAttachedFile(null);

      const assistantId = `a-${Date.now()}`;
      const assistantTimestamp = formatTimeNow();
      let bubbleInserted = false;
      let accumulatedText = '';
      let finalReply = '';
      let finalActions: Array<ProposedBrowserAction | ProposedAppLaunch> = [];

      const upsertAssistantBubble = (
        nextText: string,
        actions?: Array<ProposedBrowserAction | ProposedAppLaunch>
      ) => {
        if (!bubbleInserted) {
          bubbleInserted = true;
          setMessages((prev) => [
            ...prev,
            {
              id: assistantId,
              role: 'assistant',
              text: nextText,
              timestamp: assistantTimestamp,
              actions,
            },
          ]);
        } else {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantId
                ? {
                    ...m,
                    text: nextText,
                    actions: actions ?? m.actions,
                  }
                : m
            )
          );
        }
      };

      try {
        const res = await fetch('/api/jarvis/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: text,
            history: historyPayload,
            permissions,
            contextSummary: `Bat=${
              battery.supported && battery.levelPercent !== null
                ? `${battery.levelPercent}%`
                : 'na'
            },Net=${network.online ? 'on' : 'off'},FS=${isFullscreen},Wx=${
              weather ? `${weather.temperatureC}C ${weather.condition}` : 'na'
            }`,
            attachment: currentAttachment || undefined,
          }),
        });

        const contentType = res.headers.get('content-type') || '';

        if (!res.ok) {
          const errData = contentType.includes('application/json')
            ? ((await res.json()) as { error?: string })
            : null;
          throw new Error(errData?.error || 'JARVIS request failed.');
        }

        if (contentType.includes('text/event-stream') && res.body) {
          const reader = res.body.getReader();
          const decoder = new TextDecoder();
          let buffer = '';

          while (true) {
            const { value, done } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });

            const events = buffer.split('\n\n');
            buffer = events.pop() ?? '';

            for (const block of events) {
              const lines = block.split('\n');
              for (const line of lines) {
                if (!line.startsWith('data:')) continue;
                const jsonStr = line.slice(5).trim();
                if (!jsonStr) continue;
                const payload = JSON.parse(jsonStr) as {
                  type?: 'delta' | 'done' | 'error';
                  text?: string;
                  reply?: string;
                  actions?: Array<ProposedBrowserAction | ProposedAppLaunch>;
                  error?: string;
                };

                if (payload.type === 'delta' && payload.text) {
                  accumulatedText += payload.text;
                  upsertAssistantBubble(accumulatedText);
                } else if (payload.type === 'done') {
                  finalReply = (payload.reply || accumulatedText).trim();
                  finalActions = Array.isArray(payload.actions)
                    ? payload.actions
                    : [];
                  upsertAssistantBubble(finalReply, finalActions);
                } else if (payload.type === 'error') {
                  throw new Error(payload.error || 'JARVIS stream error.');
                }
              }
            }
          }
        } else {
          const data = (await res.json()) as {
            reply: string;
            actions?: Array<ProposedBrowserAction | ProposedAppLaunch>;
          };
          finalReply = data.reply;
          finalActions = Array.isArray(data.actions) ? data.actions : [];
          upsertAssistantBubble(finalReply, finalActions);
        }

        const spoken = finalReply || accumulatedText.trim();
        setHistoryLog((prev) => [
          {
            id: `h-${Date.now()}`,
            command: text,
            source,
            timestamp: formatTimeNow(),
            outcome:
              finalActions.length > 0
                ? `${finalActions.length} action(s) prepared`
                : 'Responded',
          },
          ...prev,
        ]);

        if (settingsRef.current.autoSpeak && spoken) {
          speakText(spoken);
        } else {
          setAiStatus('idle');
        }
      } catch (err) {
        const errMsg =
          err instanceof Error ? err.message : 'Unable to reach JARVIS backend.';
        setAiStatus('error');
        if (bubbleInserted) {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantId
                ? { ...m, text: errMsg, error: true }
                : m
            )
          );
        } else {
          setMessages((prev) => [
            ...prev,
            {
              id: `err-${Date.now()}`,
              role: 'assistant',
              text: errMsg,
              timestamp: formatTimeNow(),
              error: true,
            },
          ]);
        }
      }
    },
    [
      attachedFile,
      battery.levelPercent,
      battery.supported,
      isFullscreen,
      messages,
      network.online,
      permissions,
      speakText,
      weather,
    ]
  );

  // Execute confirmed browser action from Chat card
  const handleConfirmBrowserAction = async (
    messageId: string,
    action: ProposedBrowserAction
  ) => {
    let status: ProposedBrowserAction['status'] = 'executed';
    let resultMessage = '';

    switch (action.actionType) {
      case 'camera_open':
        setActiveSection('controls');
        await startCamera('environment');
        resultMessage = 'Opened Camera module.';
        break;
      case 'flashlight_toggle':
        setActiveSection('controls');
        await toggleTorch();
        resultMessage =
          torchSupported === false
            ? 'Torch hardware control unsupported on this browser/device.'
            : 'Processed flashlight request in Controls.';
        if (torchSupported === false) status = 'unsupported';
        break;
      case 'location_weather':
        resultMessage = await fetchWeatherWithLocation();
        break;
      case 'vibrate':
        resultMessage = triggerVibration();
        if (!('vibrate' in navigator)) status = 'unsupported';
        break;
      case 'fullscreen_enter':
      case 'fullscreen_exit':
        resultMessage = await toggleFullscreen();
        break;
      case 'clipboard_write':
        resultMessage = await copyClipboard(action.payload?.text || '');
        break;
      case 'clipboard_read': {
        const res = await readClipboard();
        resultMessage = res.ok
          ? `Clipboard content: "${res.value}"`
          : res.value;
        if (!res.ok) status = 'unsupported';
        break;
      }
      case 'screen_share':
        setActiveSection('controls');
        await startScreenShare();
        resultMessage = 'Screen share requested in Controls.';
        break;
      case 'file_select':
        setActiveSection('controls');
        resultMessage = 'Switched to Controls to select a file.';
        break;
      case 'battery_status':
        resultMessage =
          battery.supported && battery.levelPercent !== null
            ? `Battery is at ${battery.levelPercent}% (${
                battery.charging ? 'Charging' : 'On battery'
              }).`
            : 'Battery Status API is not supported in this browser.';
        if (!battery.supported) status = 'unsupported';
        break;
      default:
        status = 'unsupported';
        resultMessage = 'Unsupported browser action.';
    }

    setMessages((prev) =>
      prev.map((m) =>
        m.id === messageId
          ? {
              ...m,
              actions: m.actions?.map((a) =>
                a.id === action.id && a.kind === 'browser_action'
                  ? { ...a, status, resultMessage }
                  : a
              ),
            }
          : m
      )
    );
  };

  const handleDeclineAction = (messageId: string, actionId: string) => {
    setMessages((prev) =>
      prev.map((m) =>
        m.id === messageId
          ? {
              ...m,
              actions: m.actions?.map((a) =>
                a.id === actionId
                  ? { ...a, status: 'declined' as const }
                  : a
              ),
            }
          : m
      )
    );
  };

  const handleMarkAppLaunched = (
    messageId: string,
    action: ProposedAppLaunch
  ) => {
    setMessages((prev) =>
      prev.map((m) =>
        m.id === messageId
          ? {
              ...m,
              actions: m.actions?.map((a) =>
                a.id === action.id && a.kind === 'app_launch'
                  ? { ...a, status: 'launched' as const }
                  : a
              ),
            }
          : m
      )
    );
  };

  // Voice Command Capture (SpeechRecognition starts immediately; waveform stream attaches non-blocking)
  const stopListeningSession = useCallback(() => {
    recognitionRef.current?.stop();
    activeMicStreamRef.current?.getTracks().forEach((t) => t.stop());
    activeMicStreamRef.current = null;
    micStream?.getTracks().forEach((t) => t.stop());
    setMicStream(null);
    setIsListening(false);
  }, [micStream]);

  const toggleVoiceListen = useCallback(() => {
    if (isListening) {
      stopListeningSession();
      return;
    }

    const win = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionLike;
      webkitSpeechRecognition?: new () => SpeechRecognitionLike;
    };
    const RecognitionCtor =
      win.SpeechRecognition || win.webkitSpeechRecognition;

    if (!RecognitionCtor) {
      setMessages((prev) => [
        ...prev,
        {
          id: `v-err-${Date.now()}`,
          role: 'assistant',
          text: 'Speech Recognition API is not supported in this browser. Please use Chrome, Edge, or Safari, or type your command below.',
          timestamp: formatTimeNow(),
          error: true,
        },
      ]);
      return;
    }

    // Stop wake-word listener and TTS immediately
    wakeRecognitionRef.current?.abort();
    stopSpeaking();

    let sessionEnded = false;
    const releaseMicStream = () => {
      activeMicStreamRef.current?.getTracks().forEach((t) => t.stop());
      activeMicStreamRef.current = null;
      setMicStream(null);
    };

    const recognition = new RecognitionCtor();
    recognition.lang = settingsRef.current.language;
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    finalTranscriptRef.current = '';
    sentSpeechRef.current = false;
    setInterimTranscript('');

    recognition.onresult = (event) => {
      let interim = '';
      let finalized = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        const txt = res?.[0]?.transcript || '';
        if (res?.isFinal) finalized += txt + ' ';
        else interim += txt;
      }

      if (finalized.trim()) {
        finalTranscriptRef.current =
          `${finalTranscriptRef.current} ${finalized}`.trim();
        setInterimTranscript(finalTranscriptRef.current);
        recognition.stop();
        if (!sentSpeechRef.current) {
          sentSpeechRef.current = true;
          const cmd = finalTranscriptRef.current;
          setInterimTranscript('');
          void sendToJarvis(cmd, 'voice');
        }
      } else if (interim.trim()) {
        setInterimTranscript(interim.trim());
      }
    };

    recognition.onerror = (event) => {
      sessionEnded = true;
      setIsListening(false);
      setAiStatus('idle');
      setInterimTranscript('');
      releaseMicStream();
      if (event.error !== 'aborted' && event.error !== 'no-speech') {
        setMessages((prev) => [
          ...prev,
          {
            id: `v-err-${Date.now()}`,
            role: 'assistant',
            text: `Voice recognition error: ${event.error}. Ensure microphone permission is allowed.`,
            timestamp: formatTimeNow(),
            error: true,
          },
        ]);
      }
    };

    recognition.onend = () => {
      sessionEnded = true;
      setIsListening(false);
      releaseMicStream();
      const pending = finalTranscriptRef.current.trim();
      if (pending && !sentSpeechRef.current) {
        sentSpeechRef.current = true;
        setInterimTranscript('');
        void sendToJarvis(pending, 'voice');
      } else {
        setInterimTranscript('');
        setAiStatus((prev) => (prev === 'listening' ? 'idle' : prev));
      }
    };

    recognitionRef.current = recognition;
    setIsListening(true);
    setAiStatus('listening');
    recognition.start();

    // Non-blocking audio waveform stream attachment
    if (navigator.mediaDevices?.getUserMedia) {
      navigator.mediaDevices
        .getUserMedia({ audio: true })
        .then((stream) => {
          if (sessionEnded) {
            stream.getTracks().forEach((t) => t.stop());
            return;
          }
          activeMicStreamRef.current = stream;
          setMicStream(stream);
          void refreshPermissions();
        })
        .catch(() => {
          // SpeechRecognition continues cleanly even without waveform AudioContext access
        });
    }
  }, [
    isListening,
    refreshPermissions,
    sendToJarvis,
    stopListeningSession,
  ]);

  // Optional Wake-Word Listener ("Jarvis")
  useEffect(() => {
    if (!settings.wakeWordEnabled || isListening) {
      wakeRecognitionRef.current?.abort();
      wakeRecognitionRef.current = null;
      return;
    }

    const win = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionLike;
      webkitSpeechRecognition?: new () => SpeechRecognitionLike;
    };
    const RecognitionCtor =
      win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!RecognitionCtor) return;

    let stopped = false;
    const rec = new RecognitionCtor();
    rec.lang = settings.language;
    rec.continuous = true;
    rec.interimResults = false;
    rec.maxAlternatives = 1;

    rec.onresult = (event) => {
      const last = event.results[event.results.length - 1];
      const text = last?.[0]?.transcript?.trim() || '';
      const lower = text.toLowerCase();
      if (lower.includes('jarvis')) {
        const stripped = text.replace(/^(hey|ok|hi)?\s*jarvis[,:]?\s*/i, '').trim();
        if (stripped) {
          void sendToJarvis(stripped, 'wake_word');
        } else {
          speakText('Yes, I am listening.');
        }
      }
    };

    rec.onerror = () => {
      // Do not loop aggressively on denied permission
    };

    rec.onend = () => {
      if (!stopped && settingsRef.current.wakeWordEnabled) {
        try {
          rec.start();
        } catch {
          // Ignore restart error
        }
      }
    };

    wakeRecognitionRef.current = rec;
    try {
      rec.start();
    } catch {
      // Ignore initial start failure
    }

    return () => {
      stopped = true;
      rec.abort();
    };
  }, [settings.wakeWordEnabled, settings.language, isListening, sendToJarvis, speakText]);

  const handleNewChat = () => {
    setMessages([WELCOME_MESSAGE]);
    setAttachedFile(null);
    setActiveSection('assistant');
    setAssistantSubView('chat');
    setDrawerOpen(false);
  };

  const handleEndSession = () => {
    stopListeningSession();
    stopSpeaking();
    setInterimTranscript('');
    setAiStatus('idle');
    if (cameraStream) stopCamera();
    if (screenStream) stopScreenShare();
  };

  const navigateTo = (
    section: ActiveSection,
    subView: 'chat' | 'history' = 'chat'
  ) => {
    setActiveSection(section);
    if (section === 'assistant') {
      setAssistantSubView(subView);
    }
    setDrawerOpen(false);
  };

  const navItems: Array<{
    id: ActiveSection;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    { id: 'home', label: 'HUD Home', icon: Home },
    { id: 'assistant', label: 'AI Chat', icon: MessageSquareMore },
    { id: 'stats', label: 'Stats & Weather', icon: BarChart3 },
    { id: 'launcher', label: 'App Launcher', icon: LayoutGrid },
    { id: 'controls', label: 'Phone Controls', icon: Sliders },
    { id: 'profile', label: 'Commander Profile', icon: User },
    { id: 'permissions', label: 'Permissions', icon: ShieldCheck },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  // On desktop (lg+), the left column displays the HUD Home core, so the right column shows AI Chat when 'home' is selected
  const effectiveDesktopRightSection: ActiveSection =
    activeSection === 'home' ? 'assistant' : activeSection;

  const renderSectionPanel = (sectionToRender: ActiveSection) => {
    switch (sectionToRender) {
      case 'assistant':
        return (
          <AssistantChatPanel
            messages={messages}
            historyLog={historyLog}
            isThinking={aiStatus === 'thinking'}
            isListening={isListening}
            interimTranscript={interimTranscript}
            attachedFileName={attachedFile?.name || null}
            subView={assistantSubView}
            onChangeSubView={setAssistantSubView}
            onClearAttachment={() => setAttachedFile(null)}
            onAttachFile={(file) => setAttachedFile(file)}
            onSendMessage={sendToJarvis}
            onToggleVoiceCommand={toggleVoiceListen}
            onNavigateSection={(target) => {
              if (target === 'camera') {
                setActiveSection('controls');
                void startCamera('environment');
              } else {
                setActiveSection(target);
              }
            }}
            onConfirmBrowserAction={handleConfirmBrowserAction}
            onDeclineAction={handleDeclineAction}
            onMarkAppLaunched={handleMarkAppLaunched}
            onSpeakMessage={speakText}
          />
        );

      case 'stats':
        return (
          <div className="space-y-4">
            <SmartDashboard
              aiStatus={aiStatus}
              micPermission={permissions.microphone}
              isListening={isListening}
              battery={battery}
              network={network}
              weather={weather}
              weatherLoading={weatherLoading}
              weatherError={weatherError}
              onRequestWeather={() => {
                void fetchWeatherWithLocation();
              }}
            />

            <div className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <History className="h-4 w-4 text-cyan-400" />
                  <h2 className="text-base font-display font-semibold text-white">
                    Recent Command Analytics ({historyLog.length})
                  </h2>
                </div>
                {historyLog.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setHistoryLog([])}
                    className="text-xs text-rose-300 hover:text-rose-200 cursor-pointer"
                  >
                    Clear
                  </button>
                )}
              </div>

              {historyLog.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">
                  No voice or text commands recorded yet. Tap START VOICE or ask JARVIS in AI Chat.
                </p>
              ) : (
                <div className="divide-y divide-cyan-400/15">
                  {historyLog.slice(0, 12).map((entry) => (
                    <div
                      key={entry.id}
                      className="py-3 flex items-start justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-white truncate">
                          {entry.command}
                        </div>
                        <div className="text-xs text-slate-400">
                          {entry.source.replace('_', ' ')} · {entry.outcome}
                        </div>
                      </div>
                      <span className="text-xs text-cyan-300/75 tabular-nums shrink-0">
                        {entry.timestamp}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        );

      case 'controls':
        return (
          <WebControlsPanel
            cameraStream={cameraStream}
            cameraError={cameraError}
            torchOn={torchOn}
            torchSupported={torchSupported}
            screenStream={screenStream}
            screenError={screenError}
            isFullscreen={isFullscreen}
            onStartCamera={startCamera}
            onStopCamera={stopCamera}
            onToggleTorch={toggleTorch}
            onStartScreenShare={startScreenShare}
            onStopScreenShare={stopScreenShare}
            onToggleFullscreen={async () => {
              await toggleFullscreen();
            }}
            onVibrate={triggerVibration}
            onCopyClipboard={copyClipboard}
            onReadClipboard={readClipboard}
            onAttachFileToChat={(file) => {
              setAttachedFile({
                name: file.name,
                mimeType: file.mimeType,
                base64Data: file.base64Data,
                textContent: file.textContent,
              });
              navigateTo('assistant', 'chat');
            }}
          />
        );

      case 'launcher':
        return (
          <AppLauncherPanel
            shortcuts={shortcuts}
            isListening={isListening}
            onToggleVoiceCommand={toggleVoiceListen}
            onAddShortcut={(name, url) => {
              const newItem: AppShortcut = {
                id: `custom-${Date.now()}`,
                name,
                url,
                subtitle: 'Saved App',
                category: 'custom',
                isCustom: true,
              };
              setShortcuts((prev) => {
                const next = [...prev, newItem];
                try {
                  localStorage.setItem(
                    SHORTCUTS_STORAGE_KEY,
                    JSON.stringify(next.filter((s) => s.isCustom))
                  );
                } catch {
                  // Ignore storage failure
                }
                return next;
              });
            }}
            onRemoveShortcut={(id) => {
              setShortcuts((prev) => {
                const next = prev.filter((s) => s.id !== id);
                try {
                  localStorage.setItem(
                    SHORTCUTS_STORAGE_KEY,
                    JSON.stringify(next.filter((s) => s.isCustom))
                  );
                } catch {
                  // Ignore storage failure
                }
                return next;
              });
            }}
            onOpenCameraControl={() => {
              setActiveSection('controls');
              void startCamera('environment');
            }}
          />
        );

      case 'profile':
        return (
          <div className="space-y-5">
            <div className="rounded-2xl border border-cyan-400/35 bg-[#041022]/90 p-5 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="relative h-16 w-16 rounded-full p-[2px] bg-gradient-to-b from-cyan-300 to-cyan-500 shadow-[0_0_16px_rgba(0,212,255,0.45)] shrink-0">
                  <img
                    src="/assets/commander_portrait.png"
                    alt="Commander Ayush"
                    referrerPolicy="no-referrer"
                    className="h-full w-full rounded-full object-cover"
                  />
                </div>
                <div>
                  <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-300">
                    <Crown className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                    <span>Commander Profile</span>
                  </div>
                  <h2 className="text-lg font-display font-bold text-white">
                    Ayush Developer
                  </h2>
                  <p className="text-xs text-slate-400">
                    JARVIS Smart AI Assistant · Browser PWA Control Hub
                  </p>
                </div>
              </div>
              <PWAInstallButton onFallbackReset={handleNewChat} />
            </div>

            <PermissionManager
              permissions={permissions}
              onRefresh={refreshPermissions}
              onRequestMic={async () => {
                try {
                  const s = await navigator.mediaDevices.getUserMedia({
                    audio: true,
                  });
                  s.getTracks().forEach((t) => t.stop());
                } catch {
                  // Handled via permission refresh
                }
                await refreshPermissions();
              }}
              onRequestCamera={async () => {
                await startCamera('environment');
                await refreshPermissions();
              }}
              onRequestLocation={async () => {
                await fetchWeatherWithLocation();
              }}
              onRequestNotifications={async () => {
                if (typeof Notification !== 'undefined') {
                  await Notification.requestPermission();
                  await refreshPermissions();
                }
              }}
            />
          </div>
        );

      case 'permissions':
        return (
          <PermissionManager
            permissions={permissions}
            onRefresh={refreshPermissions}
            onRequestMic={async () => {
              try {
                const s = await navigator.mediaDevices.getUserMedia({
                  audio: true,
                });
                s.getTracks().forEach((t) => t.stop());
              } catch {
                // Handled via permission refresh
              }
              await refreshPermissions();
            }}
            onRequestCamera={async () => {
              await startCamera('environment');
              await refreshPermissions();
            }}
            onRequestLocation={async () => {
              await fetchWeatherWithLocation();
            }}
            onRequestNotifications={async () => {
              if (typeof Notification !== 'undefined') {
                await Notification.requestPermission();
                await refreshPermissions();
              }
            }}
          />
        );

      case 'settings':
        return (
          <SettingsPanel
            settings={settings}
            onChange={setSettings}
            onTestVoice={() =>
              speakText(
                settings.language === 'hi-IN'
                  ? 'Namaste Commander Ayush, main JARVIS hoon. Sabhi browser systems taiyaar hain.'
                  : 'Hello Commander Ayush, JARVIS online. All browser systems are ready.'
              )
            }
            onClearHistory={() => setHistoryLog([])}
          />
        );

      default:
        return null;
    }
  };

  const bottomTabs: Array<{
    id: ActiveSection | 'more';
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'stats', label: 'Stats', icon: BarChart3 },
    { id: 'assistant', label: 'AI Chat', icon: Crown },
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'more', label: 'More', icon: LayoutGrid },
  ];

  const isMoreActive =
    activeSection === 'launcher' ||
    activeSection === 'controls' ||
    activeSection === 'permissions' ||
    activeSection === 'settings';

  return (
    <div className="min-h-[100dvh] hud-radial-bg text-slate-100 flex flex-col">
      {/* Top HUD Bar matching screenshot: Octagon Menu | Created by Ayush Developer. | Octagon Settings */}
      <header className="sticky top-0 z-30 h-[54px] bg-[#020A17]/90 backdrop-blur-md border-b border-cyan-400/25 px-3 sm:px-6 flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => setDrawerOpen(true)}
          aria-label="Open navigation menu"
          className="hud-octagon h-10 w-10 bg-[#07182E] border border-cyan-400/50 hover:bg-[#0C2647] text-cyan-200 flex items-center justify-center shrink-0 cursor-pointer"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div className="hud-chamfer-panel px-4 sm:px-6 py-1.5 bg-gradient-to-b from-[#071B34] to-[#041022] border border-cyan-400/45 shadow-[0_0_16px_rgba(0,212,255,0.2)] flex items-center justify-center min-w-0">
          <span className="text-xs sm:text-sm font-display font-semibold text-white truncate whitespace-nowrap">
            Created by{' '}
            <strong className="text-[#00D4FF] font-bold">Ayush</strong>{' '}
            Developer.
          </span>
        </div>

        <button
          type="button"
          onClick={() => navigateTo('settings')}
          aria-label="Open settings"
          className="hud-octagon h-10 w-10 bg-[#07182E] border border-cyan-400/50 hover:bg-[#0C2647] text-cyan-200 flex items-center justify-center shrink-0 cursor-pointer"
        >
          <Settings className="h-5 w-5" />
        </button>
      </header>

      {/* Slide-Over HUD Navigation & Quick Tools Drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div
            onClick={() => setDrawerOpen(false)}
            className="fixed inset-0 bg-black/75 backdrop-blur-sm"
          />
          <aside className="relative z-10 w-[290px] max-w-[85vw] h-full bg-[#030C1B] border-r border-cyan-400/35 shadow-2xl flex flex-col">
            <div className="px-4 py-4 flex items-center justify-between border-b border-cyan-400/20">
              <div className="flex items-center gap-2.5">
                <img
                  src="/assets/commander_portrait.png"
                  alt="Commander Ayush"
                  referrerPolicy="no-referrer"
                  className="h-9 w-9 rounded-full object-cover border border-cyan-400/60"
                />
                <div>
                  <div className="text-sm font-display font-bold text-white">
                    JARVIS AI
                  </div>
                  <div className="text-[11px] text-cyan-300">
                    Commander Ayush
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                aria-label="Close menu"
                className="h-9 w-9 rounded-full bg-[#07182E] border border-cyan-400/35 flex items-center justify-center text-cyan-200 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <nav className="flex-1 overflow-y-auto thin-scrollbar p-3 space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => navigateTo(item.id)}
                    className={`w-full min-h-[44px] px-3.5 rounded-xl flex items-center gap-3 text-sm font-medium transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#092446] text-white border border-cyan-400/50'
                        : 'text-slate-300 hover:bg-cyan-500/10 hover:text-white'
                    }`}
                  >
                    <Icon className="h-4 w-4 text-cyan-400 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>

            <div className="p-3 border-t border-cyan-400/20 flex items-center justify-between gap-2">
              <PWAInstallButton onFallbackReset={handleNewChat} />
              <button
                type="button"
                onClick={handleNewChat}
                className="min-h-[40px] px-3.5 rounded-full bg-[#07182E] border border-cyan-400/35 hover:bg-[#0B2342] text-xs font-medium text-cyan-100 inline-flex items-center gap-1.5 cursor-pointer"
              >
                <SquarePen className="h-3.5 w-3.5" />
                <span>New Chat</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Responsive HUD Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 pt-3 pb-20 lg:pb-6">
        {/* Desktop Top Section Tabs for Quick Switching */}
        <div className="hidden lg:flex items-center justify-between gap-4 mb-4 pb-3 border-b border-cyan-400/20">
          <div className="flex items-center gap-2 flex-wrap">
            {(
              [
                { id: 'assistant', label: 'AI Chat' },
                { id: 'launcher', label: 'App Launcher' },
                { id: 'controls', label: 'Phone Controls' },
                { id: 'stats', label: 'Stats & Weather' },
                { id: 'profile', label: 'Commander Profile' },
                { id: 'permissions', label: 'Permissions' },
                { id: 'settings', label: 'Settings' },
              ] as Array<{ id: ActiveSection; label: string }>
            ).map((tab) => {
              const active = effectiveDesktopRightSection === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => navigateTo(tab.id)}
                  className={`min-h-[38px] px-4 rounded-full text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-[#00D4FF] text-slate-950 shadow-[0_0_14px_rgba(0,212,255,0.45)]'
                      : 'bg-[#07182E] border border-cyan-400/30 text-cyan-100 hover:border-cyan-300'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton onFallbackReset={handleNewChat} />
          </div>
        </div>

        {/* Desktop 2-Column Split (HUD Core Left + Active Workspace Right) & Mobile Single-View */}
        <div className="grid grid-cols-1 lg:grid-cols-[430px_1fr] gap-5 items-start">
          {/* Left Column on Desktop; Only shown on 'home' on Mobile */}
          <div className={activeSection === 'home' ? 'block' : 'hidden lg:block'}>
            <JarvisHudHome
              aiStatus={aiStatus}
              isListening={isListening}
              isSpeaking={isSpeaking}
              wakeWordEnabled={settings.wakeWordEnabled}
              interimTranscript={interimTranscript}
              audioStream={micStream}
              battery={battery}
              network={network}
              onToggleListen={toggleVoiceListen}
              onEndSession={handleEndSession}
              onOpenChat={(starterPrompt) => {
                navigateTo('assistant', 'chat');
                if (starterPrompt) {
                  void sendToJarvis(starterPrompt, 'text');
                }
              }}
              onOpenSection={(target) => navigateTo(target)}
            />
          </div>

          {/* Right Column on Desktop; Shown when any non-'home' tab is active on Mobile */}
          <div
            className={`min-w-0 ${
              activeSection === 'home' ? 'hidden lg:block' : 'block'
            } ${
              effectiveDesktopRightSection === 'assistant'
                ? 'h-[calc(100dvh-148px)] lg:h-[calc(100dvh-150px)]'
                : ''
            }`}
          >
            {renderSectionPanel(effectiveDesktopRightSection)}
          </div>
        </div>
      </main>

      {/* Mobile Bottom 5-Tab HUD Dock matching reference template (Home | Stats | AI Chat | Profile | More) */}
      <nav
        aria-label="Primary HUD navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-[#020A17]/95 backdrop-blur-md border-t border-cyan-400/45 shadow-[0_-4px_24px_rgba(0,212,255,0.16)] grid grid-cols-5 items-center px-1"
      >
        {bottomTabs.map((tab) => {
          const Icon = tab.icon;
          const active =
            tab.id === 'more' ? isMoreActive : activeSection === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                if (tab.id === 'more') {
                  setDrawerOpen(true);
                } else {
                  navigateTo(tab.id, 'chat');
                }
              }}
              className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors ${
                active ? 'text-[#00D4FF]' : 'text-slate-300 hover:text-white'
              }`}
            >
              <Icon
                className={`h-5 w-5 ${
                  active ? 'drop-shadow-[0_0_8px_rgba(0,212,255,0.8)]' : ''
                }`}
              />
              <span className="text-[10px] font-medium tracking-tight whitespace-nowrap">
                {tab.label}
              </span>
            </button>
          );
        })}
      </nav>

      <OfflineIndicator />
    </div>
  );
}
