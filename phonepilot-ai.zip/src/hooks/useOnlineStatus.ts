import { useEffect, useState } from 'react';
import type { NetworkSnapshot } from '../types/jarvis.ts';

interface NetworkInformationLike {
  effectiveType?: string;
  downlink?: number;
  addEventListener?: (type: string, listener: () => void) => void;
  removeEventListener?: (type: string, listener: () => void) => void;
}

export function useNetworkStatus(): NetworkSnapshot {
  const readSnapshot = (): NetworkSnapshot => {
    if (typeof navigator === 'undefined') {
      return { online: true, effectiveType: null, downlinkMbps: null };
    }
    const conn = (
      navigator as unknown as { connection?: NetworkInformationLike }
    ).connection;
    return {
      online: navigator.onLine,
      effectiveType: conn?.effectiveType || null,
      downlinkMbps: typeof conn?.downlink === 'number' ? conn.downlink : null,
    };
  };

  const [snapshot, setSnapshot] = useState<NetworkSnapshot>(readSnapshot);

  useEffect(() => {
    const update = () => setSnapshot(readSnapshot());
    window.addEventListener('online', update);
    window.addEventListener('offline', update);

    const conn = (
      navigator as unknown as { connection?: NetworkInformationLike }
    ).connection;
    conn?.addEventListener?.('change', update);

    return () => {
      window.removeEventListener('online', update);
      window.removeEventListener('offline', update);
      conn?.removeEventListener?.('change', update);
    };
  }, []);

  return snapshot;
}
