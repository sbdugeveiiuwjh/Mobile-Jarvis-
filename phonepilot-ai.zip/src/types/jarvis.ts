export type JarvisStatus = 'idle' | 'listening' | 'thinking' | 'speaking' | 'error';

export type PermissionStateValue = 'granted' | 'prompt' | 'denied' | 'unsupported' | 'unknown';

export type BrowserActionType =
  | 'camera_open'
  | 'flashlight_toggle'
  | 'location_weather'
  | 'vibrate'
  | 'fullscreen_enter'
  | 'fullscreen_exit'
  | 'clipboard_write'
  | 'clipboard_read'
  | 'file_select'
  | 'screen_share'
  | 'battery_status';

export interface ProposedBrowserAction {
  id: string;
  kind: 'browser_action';
  actionType: BrowserActionType;
  label: string;
  description: string;
  requiresConfirmation: boolean;
  payload?: {
    text?: string;
    enabled?: boolean;
  };
  status: 'pending' | 'executed' | 'declined' | 'unsupported';
  resultMessage?: string;
}

export interface ProposedAppLaunch {
  id: string;
  kind: 'app_launch';
  appName: string;
  url: string;
  description: string;
  status: 'pending' | 'launched' | 'declined';
}

export type JarvisActionCard = ProposedBrowserAction | ProposedAppLaunch;

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
  actions?: JarvisActionCard[];
  error?: boolean;
  attachmentName?: string;
}

export interface CommandHistoryEntry {
  id: string;
  command: string;
  source: 'voice' | 'text' | 'wake_word';
  timestamp: string;
  outcome: string;
}

export interface AppShortcut {
  id: string;
  name: string;
  url: string;
  subtitle?: string;
  category: 'media' | 'social' | 'utility' | 'custom';
  isCustom?: boolean;
}

export interface WeatherData {
  temperatureC: number;
  apparentC: number;
  humidity: number;
  windKmh: number;
  condition: string;
  latitude: number;
  longitude: number;
  updatedAt: string;
}

export interface BatterySnapshot {
  supported: boolean;
  levelPercent: number | null;
  charging: boolean | null;
}

export interface NetworkSnapshot {
  online: boolean;
  effectiveType: string | null;
  downlinkMbps: number | null;
}

export interface PermissionMatrix {
  microphone: PermissionStateValue;
  camera: PermissionStateValue;
  geolocation: PermissionStateValue;
  clipboardRead: PermissionStateValue;
  notifications: PermissionStateValue;
  speechRecognition: boolean;
  speechSynthesis: boolean;
  batteryApi: boolean;
  vibrationApi: boolean;
  fullscreenApi: boolean;
  screenShareApi: boolean;
}

export interface JarvisSettings {
  language: 'en-IN' | 'hi-IN' | 'en-US';
  autoSpeak: boolean;
  speechRate: number;
  speechPitch: number;
  wakeWordEnabled: boolean;
  confirmSensitiveActions: boolean;
}
