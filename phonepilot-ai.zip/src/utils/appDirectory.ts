export interface KnownAppEntry {
  id: string;
  name: string;
  aliases: string[];
  url: string;
  category: 'media' | 'social' | 'utility';
  subtitle: string;
}

export const KNOWN_APPS: KnownAppEntry[] = [
  {
    id: 'youtube',
    name: 'YouTube',
    aliases: ['yt', 'you tube'],
    url: 'https://www.youtube.com',
    category: 'media',
    subtitle: 'Video & Search App',
  },
  {
    id: 'instagram',
    name: 'Instagram',
    aliases: ['insta', 'ig'],
    url: 'https://www.instagram.com',
    category: 'social',
    subtitle: 'Social & Reels App',
  },
  {
    id: 'whatsapp',
    name: 'WhatsApp',
    aliases: ['wa', 'whats app'],
    url: 'https://wa.me/',
    category: 'social',
    subtitle: 'Messaging App',
  },
  {
    id: 'google',
    name: 'Google',
    aliases: ['google search', 'google app'],
    url: 'https://www.google.com',
    category: 'utility',
    subtitle: 'Search App',
  },
  {
    id: 'maps',
    name: 'Google Maps',
    aliases: ['maps', 'map', 'navigation'],
    url: 'https://maps.google.com',
    category: 'utility',
    subtitle: 'Navigation App',
  },
  {
    id: 'spotify',
    name: 'Spotify',
    aliases: ['spotify music'],
    url: 'https://open.spotify.com',
    category: 'media',
    subtitle: 'Music App',
  },
  {
    id: 'phone',
    name: 'Phone Dialer',
    aliases: ['dialer', 'call', 'phone'],
    url: 'tel:',
    category: 'utility',
    subtitle: 'System Dialer',
  },
  {
    id: 'messages',
    name: 'Messages',
    aliases: ['sms', 'messaging', 'text message'],
    url: 'sms:',
    category: 'social',
    subtitle: 'System SMS App',
  },
  {
    id: 'gmail',
    name: 'Gmail',
    aliases: ['email', 'mail'],
    url: 'https://mail.google.com',
    category: 'utility',
    subtitle: 'Mail App',
  },
  {
    id: 'telegram',
    name: 'Telegram',
    aliases: ['tg'],
    url: 'https://t.me',
    category: 'social',
    subtitle: 'Messaging App',
  },
  {
    id: 'snapchat',
    name: 'Snapchat',
    aliases: ['snap'],
    url: 'https://www.snapchat.com',
    category: 'social',
    subtitle: 'Camera & Social App',
  },
  {
    id: 'facebook',
    name: 'Facebook',
    aliases: ['fb'],
    url: 'https://www.facebook.com',
    category: 'social',
    subtitle: 'Social App',
  },
  {
    id: 'x',
    name: 'X (Twitter)',
    aliases: ['twitter', 'x'],
    url: 'https://x.com',
    category: 'social',
    subtitle: 'Social App',
  },
  {
    id: 'netflix',
    name: 'Netflix',
    aliases: [],
    url: 'https://www.netflix.com',
    category: 'media',
    subtitle: 'Streaming App',
  },
  {
    id: 'amazon',
    name: 'Amazon',
    aliases: ['amazon shopping'],
    url: 'https://www.amazon.in',
    category: 'utility',
    subtitle: 'Shopping App',
  },
  {
    id: 'flipkart',
    name: 'Flipkart',
    aliases: [],
    url: 'https://www.flipkart.com',
    category: 'utility',
    subtitle: 'Shopping App',
  },
  {
    id: 'paytm',
    name: 'Paytm',
    aliases: [],
    url: 'https://paytm.com',
    category: 'utility',
    subtitle: 'Payments App',
  },
  {
    id: 'phonepe',
    name: 'PhonePe',
    aliases: ['phone pe'],
    url: 'https://www.phonepe.com',
    category: 'utility',
    subtitle: 'Payments App',
  },
  {
    id: 'gpay',
    name: 'Google Pay',
    aliases: ['gpay', 'g pay'],
    url: 'https://pay.google.com',
    category: 'utility',
    subtitle: 'Payments App',
  },
  {
    id: 'discord',
    name: 'Discord',
    aliases: [],
    url: 'https://discord.com/app',
    category: 'social',
    subtitle: 'Voice & Chat App',
  },
  {
    id: 'zoom',
    name: 'Zoom',
    aliases: [],
    url: 'https://zoom.us/join',
    category: 'utility',
    subtitle: 'Meetings App',
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    aliases: [],
    url: 'https://www.linkedin.com',
    category: 'social',
    subtitle: 'Network App',
  },
  {
    id: 'playstore',
    name: 'Play Store',
    aliases: ['google play', 'play store', 'app store'],
    url: 'https://play.google.com/store',
    category: 'utility',
    subtitle: 'App Marketplace',
  },
];

const BLOCKED_SCHEMES = /^(javascript|data|vbscript|file):/i;

export function isSafeAppLaunchUrl(raw: string): boolean {
  const trimmed = raw.trim();
  if (!trimmed || BLOCKED_SCHEMES.test(trimmed)) return false;
  return (
    trimmed.startsWith('https://') ||
    trimmed.startsWith('http://') ||
    trimmed.startsWith('tel:') ||
    trimmed.startsWith('sms:') ||
    trimmed.startsWith('mailto:') ||
    /^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed)
  );
}

export function resolveAppLaunchTarget(
  appNameRaw: string,
  customSchemeRaw?: string
): {
  appName: string;
  url: string;
  description: string;
  matchedKnown: boolean;
} {
  const cleanName = appNameRaw.trim() || 'App';
  const lower = cleanName.toLowerCase();

  if (customSchemeRaw && customSchemeRaw.trim()) {
    const scheme = customSchemeRaw.trim();
    if (isSafeAppLaunchUrl(scheme)) {
      return {
        appName: cleanName,
        url: scheme,
        description: `Launch ${cleanName} via app link`,
        matchedKnown: false,
      };
    }
  }

  const matched = KNOWN_APPS.find(
    (entry) =>
      entry.name.toLowerCase() === lower ||
      entry.id.toLowerCase() === lower ||
      entry.aliases.some((a) => a.toLowerCase() === lower)
  );

  if (matched) {
    return {
      appName: matched.name,
      url: matched.url,
      description: `Open ${matched.name} app`,
      matchedKnown: true,
    };
  }

  return {
    appName: cleanName,
    url: `https://play.google.com/store/search?q=${encodeURIComponent(
      cleanName
    )}&c=apps`,
    description: `Open ${cleanName} via Play Store App link`,
    matchedKnown: false,
  };
}
