import express from 'express';
import http from 'http';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import {
  GoogleGenAI,
  ThinkingLevel,
  Type,
  type Content,
  type FunctionCall,
  type FunctionDeclaration,
  type Part,
} from '@google/genai';
import type {
  BrowserActionType,
  JarvisActionCard,
  PermissionMatrix,
} from './src/types/jarvis.ts';
import {
  isSafeAppLaunchUrl,
  resolveAppLaunchTarget,
} from './src/utils/appDirectory.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);

let cachedAi: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY is missing. Please add it in Settings > Secrets.'
    );
  }
  if (!cachedAi) {
    cachedAi = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return cachedAi;
}

function wmoToCondition(code: number): string {
  if (code === 0) return 'Clear sky';
  if (code <= 3) return 'Partly cloudy';
  if (code === 45 || code === 48) return 'Foggy';
  if (code >= 51 && code <= 57) return 'Drizzle';
  if (code >= 61 && code <= 67) return 'Rain';
  if (code >= 71 && code <= 77) return 'Snow';
  if (code >= 80 && code <= 82) return 'Rain showers';
  if (code >= 95) return 'Thunderstorm';
  return 'Cloudy';
}

const jarvisToolDeclarations: FunctionDeclaration[] = [
  {
    name: 'propose_browser_action',
    description:
      'Propose a supported Web Browser API action for the client device. Sensitive APIs require user confirmation before execution.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        actionType: {
          type: Type.STRING,
          description:
            'Must be one of: "camera_open", "flashlight_toggle", "location_weather", "vibrate", "fullscreen_enter", "fullscreen_exit", "clipboard_write", "clipboard_read", "file_select", "screen_share", "battery_status".',
        },
        label: {
          type: Type.STRING,
          description: 'Short human-readable button label, e.g. "Open Camera", "Get Weather", "Enter Fullscreen".',
        },
        description: {
          type: Type.STRING,
          description: 'Clear explanation of what browser permission or action will run.',
        },
        spokenReply: {
          type: Type.STRING,
          description:
            'Direct 1-2 sentence natural reply to the user in their language (Hindi, Hinglish, or English) confirming the action card is ready.',
        },
        textToCopy: {
          type: Type.STRING,
          description: 'Text to copy if actionType is "clipboard_write".',
        },
        flashlightEnabled: {
          type: Type.BOOLEAN,
          description: 'True or false when actionType is "flashlight_toggle".',
        },
      },
      required: ['actionType', 'label', 'description', 'spokenReply'],
    },
  },
  {
    name: 'propose_app_launch',
    description:
      'Prepare a one-tap launch card to open a mobile/web app such as YouTube (including search queries), Instagram, WhatsApp, Google, Maps, Spotify, Phone Dialer (tel:), Messages (sms:), or any named app via its universal app link or Play Store app entry.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        appName: {
          type: Type.STRING,
          description: 'Display name of the app, e.g. "YouTube", "WhatsApp", "Instagram", "Spotify".',
        },
        url: {
          type: Type.STRING,
          description:
            'App universal link or safe URI (e.g. https://www.youtube.com/results?search_query=..., https://wa.me/, https://www.instagram.com, tel:, sms:, or https://play.google.com/store/search?q=AppName&c=apps).',
        },
        description: {
          type: Type.STRING,
          description: 'Short note describing the app launch action.',
        },
        spokenReply: {
          type: Type.STRING,
          description:
            'Direct 1-2 sentence natural reply to the user in their language (Hindi, Hinglish, or English) confirming the app launch button is ready.',
        },
      },
      required: ['appName', 'url', 'description', 'spokenReply'],
    },
  },
  {
    name: 'report_unsupported_action',
    description:
      'Call this when the user asks for an OS-level phone capability that web browsers cannot perform (such as unlocking the phone lockscreen, changing system Wi-Fi/Bluetooth, reading private SMS, or placing silent background calls).',
    parameters: {
      type: Type.OBJECT,
      properties: {
        requestedAction: {
          type: Type.STRING,
          description: 'What the user asked for.',
        },
        reason: {
          type: Type.STRING,
          description: 'Clear explanation of why browser security prevents this.',
        },
        spokenReply: {
          type: Type.STRING,
          description:
            'Direct 1-2 sentence honest explanation in the user language (Hindi, Hinglish, or English) stating this OS action is blocked by browser security and what the browser can do instead.',
        },
      },
      required: ['requestedAction', 'reason', 'spokenReply'],
    },
  },
];

const SENSITIVE_ACTIONS = new Set<BrowserActionType>([
  'camera_open',
  'flashlight_toggle',
  'location_weather',
  'clipboard_read',
  'screen_share',
  'file_select',
]);

const VALID_BROWSER_ACTION_TYPES: BrowserActionType[] = [
  'camera_open',
  'flashlight_toggle',
  'location_weather',
  'vibrate',
  'fullscreen_enter',
  'fullscreen_exit',
  'clipboard_write',
  'clipboard_read',
  'file_select',
  'screen_share',
  'battery_status',
];

const JARVIS_SYSTEM_INSTRUCTION = `You are JARVIS AI, a fast, calm, intelligent AI Web Assistant running inside a mobile/desktop browser.
You understand English, Hindi, and Hinglish seamlessly. Always respond naturally in the exact language/script style the user used.

CRITICAL RULES:
1. Browser Sandbox Honesty: You MUST NEVER claim you can unlock a phone lockscreen, toggle OS Wi-Fi/Bluetooth/Airplane mode, read private SMS/contacts, or place silent background cellular calls. Call \`report_unsupported_action\` and explain clearly what the browser cannot do vs. what it allows.
2. Supported Browser APIs: For camera, flashlight/torch, location/weather, vibration, fullscreen, clipboard copy/read, file picker, screen sharing, or battery check, call \`propose_browser_action\` with the exact \`actionType\`.
3. App Launcher (Apps Only): When the user asks to open YouTube (with or without a search query), Instagram, WhatsApp, Google, Maps, Spotify, Telegram, Phone Dialer (tel:), Messages (sms:), or any other named app, call \`propose_app_launch\` using the app's universal app link or Play Store app search link (\`https://play.google.com/store/search?q=<AppName>&c=apps\`). Focus strictly on launching apps (do not offer generic website browsing).
4. Speed & Voice Clarity: Keep replies crisp (1–3 short sentences), direct, and easy for speech synthesis (avoid long markdown bullet lists or noisy symbols). When calling any tool, ALWAYS fill \`spokenReply\` with the complete user-facing reply in that single call.`;

function formatCompactPermissions(permissions?: PermissionMatrix): string {
  if (!permissions) return 'unknown';
  return `mic=${permissions.microphone},cam=${permissions.camera},geo=${permissions.geolocation},clip=${permissions.clipboardRead}`;
}

function isHindiStyle(text: string): boolean {
  if (/[\u0900-\u097F]/.test(text)) return true;
  return /\b(karo|kholo|batao|dikhao|mera|meri|mere|kya|tum|aap|kaise|kaisa|chalu|band|hatao|karna|kar sakte|kitni|kitna)\b/i.test(
    text
  );
}

function tryFastCommand(
  message: string
): { reply: string; actions: JarvisActionCard[] } | null {
  const clean = message.trim().replace(/[?!.।]+$/g, '').trim();
  const lower = clean.toLowerCase();
  const hindi = isHindiStyle(clean);
  const id = `act-fast-${Date.now()}`;

  if (
    /^(open camera|start camera|camera open karo|camera kholo|camera chalu karo)$/i.test(
      lower
    )
  ) {
    return {
      reply: hindi
        ? 'Camera taiyaar hai. Neeche Authorize & Run par tap karein.'
        : 'Camera action is ready. Tap Authorize & Run below to open it.',
      actions: [
        {
          id,
          kind: 'browser_action',
          actionType: 'camera_open',
          label: 'Open Camera',
          description: 'Request browser camera access and open live preview.',
          requiresConfirmation: true,
          status: 'pending',
        },
      ],
    };
  }

  if (
    /^(flashlight on|torch on|turn on flashlight|flashlight on karo|torch on karo|light on karo)$/i.test(
      lower
    )
  ) {
    return {
      reply: hindi
        ? 'Flashlight control taiyaar hai. Confirm karne par browser hardware torch check karega.'
        : 'Flashlight toggle is ready. Confirm below to check and toggle device torch.',
      actions: [
        {
          id,
          kind: 'browser_action',
          actionType: 'flashlight_toggle',
          label: 'Toggle Flashlight',
          description: 'Attempt to enable camera torch if supported by your browser hardware.',
          requiresConfirmation: true,
          payload: { enabled: true },
          status: 'pending',
        },
      ],
    };
  }

  if (
    /^(vibrate|vibrate my phone|vibrate phone|phone vibrate karo|vibrate karo)$/i.test(
      lower
    )
  ) {
    return {
      reply: hindi
        ? 'Vibration command taiyaar hai. Neeche Execute par tap karein.'
        : 'Vibration pulse is ready. Tap Execute below.',
      actions: [
        {
          id,
          kind: 'browser_action',
          actionType: 'vibrate',
          label: 'Vibrate Device',
          description: 'Trigger a short vibration pulse using navigator.vibrate.',
          requiresConfirmation: false,
          status: 'pending',
        },
      ],
    };
  }

  if (
    /^(fullscreen|enter fullscreen|fullscreen mode|fullscreen karo|fullscreen on karo)$/i.test(
      lower
    )
  ) {
    return {
      reply: hindi
        ? 'Fullscreen mode taiyaar hai. Execute par tap karein.'
        : 'Fullscreen mode is ready. Tap Execute below.',
      actions: [
        {
          id,
          kind: 'browser_action',
          actionType: 'fullscreen_enter',
          label: 'Enter Fullscreen',
          description: 'Expand JARVIS AI to fullscreen display.',
          requiresConfirmation: false,
          status: 'pending',
        },
      ],
    };
  }

  if (/^(exit fullscreen|fullscreen exit|fullscreen band karo|fullscreen hatao)$/i.test(lower)) {
    return {
      reply: hindi
        ? 'Fullscreen exit action taiyaar hai. Execute par tap karein.'
        : 'Exit fullscreen action is ready. Tap Execute below.',
      actions: [
        {
          id,
          kind: 'browser_action',
          actionType: 'fullscreen_exit',
          label: 'Exit Fullscreen',
          description: 'Return from fullscreen mode.',
          requiresConfirmation: false,
          status: 'pending',
        },
      ],
    };
  }

  if (
    /^(check battery|battery status|battery kitni hai|battery check karo)$/i.test(
      lower
    )
  ) {
    return {
      reply: hindi
        ? 'Battery status check taiyaar hai. Neeche Execute par tap karein.'
        : 'Battery check is ready. Tap Execute below.',
      actions: [
        {
          id,
          kind: 'browser_action',
          actionType: 'battery_status',
          label: 'Check Battery',
          description: 'Read battery level and charging status via Battery API.',
          requiresConfirmation: false,
          status: 'pending',
        },
      ],
    };
  }

  if (
    /^(check weather|get weather|weather kaisa hai|mausam batao|weather batao)$/i.test(
      lower
    )
  ) {
    return {
      reply: hindi
        ? 'Live weather ke liye location permission zaroori hai. Neeche Authorize & Run par tap karein.'
        : 'Live weather requires your browser location. Tap Authorize & Run below.',
      actions: [
        {
          id,
          kind: 'browser_action',
          actionType: 'location_weather',
          label: 'Get Live Weather',
          description: 'Request Geolocation access to fetch current local weather.',
          requiresConfirmation: true,
          status: 'pending',
        },
      ],
    };
  }

  const ytSearchPatterns = [
    /^(?:open\s+)?youtube\s+(?:par|pe|mein|me|and\s+search|search)\s+(.+?)(?:\s+(?:search\s+karo|chalao|dikhao|play\s+karo|kholo))?$/i,
    /^search\s+(.+?)\s+on\s+youtube$/i,
    /^youtube\s+(.+?)\s+(?:search\s+karo|chalao|dikhao)$/i,
  ];
  for (const pat of ytSearchPatterns) {
    const m = clean.match(pat);
    const query = m?.[1]?.trim();
    if (query) {
      return {
        reply: hindi
          ? `YouTube par "${query}" search taiyaar hai. Neeche Launch par tap karein.`
          : `YouTube search for "${query}" is ready. Tap Launch below.`,
        actions: [
          {
            id,
            kind: 'app_launch',
            appName: `YouTube: ${query}`,
            url: `https://www.youtube.com/results?search_query=${encodeURIComponent(
              query
            )}`,
            description: `Open YouTube app with search results for "${query}"`,
            status: 'pending',
          },
        ],
      };
    }
  }

  const googleSearchPatterns = [
    /^(?:open\s+)?google\s+(?:par|pe|mein|me|and\s+search|search)\s+(.+?)(?:\s+(?:search\s+karo|dikhao|kholo))?$/i,
    /^search\s+(.+?)\s+on\s+google$/i,
  ];
  for (const pat of googleSearchPatterns) {
    const m = clean.match(pat);
    const query = m?.[1]?.trim();
    if (query) {
      return {
        reply: hindi
          ? `Google par "${query}" search taiyaar hai. Neeche Launch par tap karein.`
          : `Google search for "${query}" is ready. Tap Launch below.`,
        actions: [
          {
            id,
            kind: 'app_launch',
            appName: `Google: ${query}`,
            url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
            description: `Open Google with search for "${query}"`,
            status: 'pending',
          },
        ],
      };
    }
  }

  const openAppMatch =
    clean.match(/^(?:open|launch|start)\s+(.+?)(?:\s+app)?$/i) ||
    clean.match(/^(.+?)(?:\s+app)?\s+(?:open\s+karo|kholo|chalu\s+karo|launch\s+karo)$/i);

  if (openAppMatch?.[1]) {
    const targetRaw = openAppMatch[1]
      .replace(/^(mera|meri|mere|my|the)\s+/i, '')
      .trim();
    const lowerTarget = targetRaw.toLowerCase();

    if (lowerTarget === 'camera') {
      return {
        reply: hindi
          ? 'Camera taiyaar hai. Neeche Authorize & Run par tap karein.'
          : 'Camera action is ready. Tap Authorize & Run below to open it.',
        actions: [
          {
            id,
            kind: 'browser_action',
            actionType: 'camera_open',
            label: 'Open Camera',
            description: 'Request browser camera access and open live preview.',
            requiresConfirmation: true,
            status: 'pending',
          },
        ],
      };
    }

    const osBlockedKeywords = /\b(settings|wifi|wi-fi|bluetooth|hotspot|airplane|lockscreen|phone|screen|system)\b/i;
    if (!osBlockedKeywords.test(lowerTarget) && targetRaw.length <= 40) {
      const resolved = resolveAppLaunchTarget(targetRaw);
      return {
        reply: resolved.matchedKnown
          ? hindi
            ? `${resolved.appName} app taiyaar hai. Neeche Launch par tap karein.`
            : `${resolved.appName} app is ready. Tap Launch below.`
          : hindi
          ? `${resolved.appName} ke liye App Launcher link taiyaar hai. Neeche Launch par tap karein.`
          : `Prepared an app launch link for ${resolved.appName}. Tap Launch below.`,
        actions: [
          {
            id,
            kind: 'app_launch',
            appName: resolved.appName,
            url: resolved.url,
            description: resolved.description,
            status: 'pending',
          },
        ],
      };
    }
  }

  return null;
}

function formatGeminiError(error: unknown): string {
  const raw =
    error instanceof Error
      ? error.message
      : 'Failed to communicate with JARVIS AI.';
  if (raw.includes('503') || raw.includes('UNAVAILABLE') || raw.includes('high demand')) {
    return 'AI service is temporarily busy. Please try again in a few seconds.';
  }
  if (raw.includes('429') || raw.includes('RESOURCE_EXHAUSTED')) {
    return 'API rate limit reached temporarily. Please wait a moment or check your Gemini API quota in Settings > Secrets.';
  }
  if (
    raw.includes('API_KEY_INVALID') ||
    raw.includes('403') ||
    raw.includes('PERMISSION_DENIED')
  ) {
    return 'Gemini API key error. Please verify your key in Settings > Secrets.';
  }
  return raw;
}

async function startServer() {
  const app = express();
  const httpServer = http.createServer(app);
  app.use(express.json({ limit: '6mb' }));

  app.get('/api/weather', async (req, res) => {
    try {
      const lat = Number(req.query.lat);
      const lon = Number(req.query.lon);
      if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
        res.status(400).json({ error: 'Valid latitude and longitude are required.' });
        return;
      }

      const url = `https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(
        lat
      )}&longitude=${encodeURIComponent(
        lon
      )}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m`;

      const upstream = await fetch(url);
      if (!upstream.ok) {
        throw new Error(`Weather service returned ${upstream.status}`);
      }
      const data = (await upstream.json()) as {
        current?: {
          temperature_2m?: number;
          apparent_temperature?: number;
          relative_humidity_2m?: number;
          wind_speed_10m?: number;
          weather_code?: number;
        };
      };

      const cur = data.current;
      if (!cur || typeof cur.temperature_2m !== 'number') {
        throw new Error('Weather data unavailable for this location.');
      }

      res.json({
        temperatureC: cur.temperature_2m,
        apparentC: cur.apparent_temperature ?? cur.temperature_2m,
        humidity: cur.relative_humidity_2m ?? 0,
        windKmh: cur.wind_speed_10m ?? 0,
        condition: wmoToCondition(cur.weather_code ?? 0),
        latitude: lat,
        longitude: lon,
        updatedAt: new Date().toLocaleTimeString('en-IN', {
          hour: '2-digit',
          minute: '2-digit',
          hour12: true,
        }),
      });
    } catch (error) {
      const msg =
        error instanceof Error ? error.message : 'Unable to fetch weather.';
      res.status(502).json({ error: msg });
    }
  });

  app.post('/api/jarvis/chat', async (req, res) => {
    let streamStarted = false;

    const sendSse = (payload: Record<string, unknown>) => {
      res.write(`data: ${JSON.stringify(payload)}\n\n`);
    };

    try {
      const { message, history, permissions, contextSummary, attachment } =
        req.body as {
          message: string;
          history?: Array<{ role: 'user' | 'assistant'; text: string }>;
          permissions?: PermissionMatrix;
          contextSummary?: string;
          attachment?: {
            name: string;
            mimeType: string;
            base64Data?: string;
            textContent?: string;
          };
        };

      if (!message || typeof message !== 'string') {
        res.status(400).json({ error: 'Message is required.' });
        return;
      }

      res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('X-Accel-Buffering', 'no');
      res.flushHeaders?.();
      streamStarted = true;

      if (!attachment) {
        const fast = tryFastCommand(message);
        if (fast) {
          sendSse({ type: 'delta', text: fast.reply });
          sendSse({ type: 'done', reply: fast.reply, actions: fast.actions });
          res.end();
          return;
        }
      }

      const ai = getAiClient();

      const contents: Content[] = [];
      if (Array.isArray(history)) {
        for (const item of history.slice(-6)) {
          if (!item.text?.trim()) continue;
          contents.push({
            role: item.role === 'user' ? 'user' : 'model',
            parts: [{ text: item.text }],
          });
        }
      }

      const envInfo = `[Perm: ${formatCompactPermissions(permissions)} | ${
        contextSummary || 'none'
      }]`;

      const userParts: Part[] = [{ text: `${envInfo}\nUser: ${message}` }];

      if (attachment?.base64Data && attachment.mimeType.startsWith('image/')) {
        userParts.push({
          inlineData: {
            mimeType: attachment.mimeType,
            data: attachment.base64Data,
          },
        });
      } else if (attachment?.textContent) {
        userParts.push({
          text: `\nAttached file (${attachment.name}):\n${attachment.textContent.slice(
            0,
            6000
          )}`,
        });
      }

      contents.push({ role: 'user', parts: userParts });

      const modelAttempts: Array<{
        model: string;
        thinkingLevel: ThinkingLevel;
      }> = [
        {
          model: 'gemini-3.1-flash-lite',
          thinkingLevel: ThinkingLevel.MINIMAL,
        },
        {
          model: 'gemini-4-hydrogen',
          thinkingLevel: ThinkingLevel.LOW,
        },
      ];

      let streamedText = '';
      const collectedCalls: FunctionCall[] = [];
      let lastError: unknown = null;

      for (let i = 0; i < modelAttempts.length; i++) {
        const attempt = modelAttempts[i];
        try {
          const stream = await ai.models.generateContentStream({
            model: attempt.model,
            contents,
            config: {
              thinkingConfig: { thinkingLevel: attempt.thinkingLevel },
              systemInstruction: JARVIS_SYSTEM_INSTRUCTION,
              tools: [{ functionDeclarations: jarvisToolDeclarations }],
            },
          });

          for await (const chunk of stream) {
            if (chunk.text) {
              streamedText += chunk.text;
              sendSse({ type: 'delta', text: chunk.text });
            }
            if (chunk.functionCalls && chunk.functionCalls.length > 0) {
              collectedCalls.push(...chunk.functionCalls);
            }
          }
          lastError = null;
          break;
        } catch (err) {
          lastError = err;
          const canRetryFallback =
            i < modelAttempts.length - 1 &&
            !streamedText &&
            collectedCalls.length === 0;
          if (!canRetryFallback) {
            throw err;
          }
        }
      }

      if (lastError) {
        throw lastError;
      }

      const actions: JarvisActionCard[] = [];
      const spokenFallbacks: string[] = [];

      for (const call of collectedCalls) {
        const name = call.name || '';
        const args = (call.args as Record<string, unknown>) || {};
        const actionId = `act-${Date.now()}-${Math.random()
          .toString(36)
          .slice(2, 6)}`;

        if (typeof args.spokenReply === 'string' && args.spokenReply.trim()) {
          spokenFallbacks.push(args.spokenReply.trim());
        }

        if (name === 'propose_browser_action') {
          const actionType = String(
            args.actionType || 'battery_status'
          ) as BrowserActionType;
          const safeType = VALID_BROWSER_ACTION_TYPES.includes(actionType)
            ? actionType
            : 'battery_status';

          actions.push({
            id: actionId,
            kind: 'browser_action',
            actionType: safeType,
            label: String(args.label || 'Run Browser Action'),
            description: String(
              args.description || 'Execute browser Web API action.'
            ),
            requiresConfirmation: SENSITIVE_ACTIONS.has(safeType),
            payload: {
              text:
                typeof args.textToCopy === 'string'
                  ? args.textToCopy
                  : undefined,
              enabled:
                typeof args.flashlightEnabled === 'boolean'
                  ? args.flashlightEnabled
                  : undefined,
            },
            status: 'pending',
          });
        } else if (name === 'propose_app_launch') {
          const rawUrl = String(args.url || '').trim();
          const fallback = resolveAppLaunchTarget(
            String(args.appName || 'App')
          );
          const safeUrl = isSafeAppLaunchUrl(rawUrl) ? rawUrl : fallback.url;

          actions.push({
            id: actionId,
            kind: 'app_launch',
            appName: String(args.appName || fallback.appName),
            url: safeUrl,
            description: String(
              args.description || `Open ${String(args.appName || fallback.appName)} app`
            ),
            status: 'pending',
          });
        } else if (name === 'report_unsupported_action') {
          if (
            spokenFallbacks.length === 0 &&
            typeof args.reason === 'string' &&
            args.reason.trim()
          ) {
            spokenFallbacks.push(args.reason.trim());
          }
        }
      }

      let finalReply = streamedText.trim();
      if (!finalReply) {
        finalReply =
          spokenFallbacks.join(' ').trim() ||
          (actions.length > 0
            ? 'Action prepared. Please confirm below to execute it in your browser.'
            : 'I am ready. How can I assist you?');
        sendSse({ type: 'delta', text: finalReply });
      }

      sendSse({
        type: 'done',
        reply: finalReply,
        actions,
      });
      res.end();
    } catch (error) {
      console.error('JARVIS chat error:', error);
      const message = formatGeminiError(error);
      if (!streamStarted) {
        res.status(500).json({ error: message });
      } else {
        sendSse({ type: 'error', error: message });
        res.end();
      }
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const hmrDisabled = process.env.DISABLE_HMR === 'true';
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        ws: { server: httpServer },
        hmr: !hmrDisabled,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`JARVIS AI server listening on http://localhost:${PORT}`);
  });
}

startServer();
