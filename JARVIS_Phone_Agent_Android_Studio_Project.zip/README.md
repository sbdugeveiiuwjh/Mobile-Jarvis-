# JARVIS Phone Agent (Android starter)

A small Android Studio starter app with a Hindi voice-command interface.

## Current working actions
- Voice input using Android SpeechRecognizer (microphone permission required)
- Spoken responses using Android TextToSpeech
- Open YouTube (and search YouTube if words follow the command)
- Open WhatsApp, Instagram and Chrome if installed
- Open Android Settings and Camera intent
- Read battery percentage
- Open the system dialer for a call
- Open the SMS composer for the user to review and send

## Important limits
- This is a starter project, not a full unrestricted phone-control agent.
- It does not unlock the phone, bypass PIN/fingerprint, silently place calls, or silently send messages.
- Android restricts background microphone use, app access, and automation. Additional features require user-granted permissions and must follow Android policies.
- Contact-name dialing, WhatsApp message sending, always-on wake word, Gemini integration, and accessibility-based workflows are not implemented in this starter.

## Build
1. Install Android Studio (stable version) on a computer.
2. Open this folder as a project.
3. Let Gradle sync; install Android SDK 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

To create an APK: Android Studio > Build > Build Bundle(s) / APK(s) > Build APK(s).

## API key
No paid AI API key is required for this basic starter. The command matching is local. Gemini can be integrated later for more flexible language understanding; keep any API key out of public source control.
