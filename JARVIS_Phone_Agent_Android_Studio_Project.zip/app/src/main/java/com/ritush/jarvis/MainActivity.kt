package com.ritush.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var onResult: ((String) -> Unit)? = null
    private var permissionGranted = false

    private val audioPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted = granted
        if (granted) startListeningInternal()
        else speak("Microphone permission allow karna zaroori hai.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent { JarvisScreen(
            onListen = { callback ->
                onResult = callback
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    startListeningInternal()
                } else audioPermission.launch(Manifest.permission.RECORD_AUDIO)
            },
            onCommand = { command -> handleCommand(command) }
        ) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
    }

    private fun speak(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun startListeningInternal() {
        val recognizer = speechRecognizer ?: run {
            speak("Is device par speech recognition available nahi hai.")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS ko command dein")
        }
        recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                onResult?.invoke("Voice recognition error. Dobara try karein.")
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                onResult?.invoke(text.ifBlank { "Koi command samajh nahi aayi." })
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        val c = raw.lowercase(Locale.ROOT).trim()
        when {
            c.contains("youtube") || c.contains("यूट्यूब") -> {
                val query = c.replace("youtube", "").replace("यूट्यूब", "").replace(" kholo", "").trim()
                val intent = if (query.isNotBlank()) Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}"))
                    else packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                        ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                launch(intent); speak("YouTube khol raha hoon.")
            }
            c.contains("whatsapp") || c.contains("व्हाट्सएप") -> openPackage("com.whatsapp", "WhatsApp")
            c.contains("instagram") || c.contains("इंस्टाग्राम") -> openPackage("com.instagram.android", "Instagram")
            c.contains("chrome") || c.contains("browser") -> openPackage("com.android.chrome", "Chrome")
            c.contains("camera") || c.contains("कैमरा") -> launch(Intent("android.media.action.IMAGE_CAPTURE").also { })
            c.contains("settings") || c.contains("सेटिंग") -> launch(Intent(android.provider.Settings.ACTION_SETTINGS))
            c.contains("battery") || c.contains("बैटरी") -> {
                val level = getSystemService(android.content.Context.BATTERY_SERVICE) as android.os.BatteryManager
                val pct = level.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
                speak("Battery $pct percent hai.")
            }
            c.contains("call") || c.contains("कॉल") || c.contains("फोन लगाओ") -> {
                speak("Kis number par call karna hai? Number type karke Call button dabayein.")
                showDialer()
            }
            c.contains("message") || c.contains("मैसेज") || c.contains("sms") -> {
                speak("Message compose screen khol raha hoon. Recipient aur message check karke khud send karein.")
                composeSms()
            }
            else -> {
                speak("Ye command abhi supported nahi hai. YouTube, WhatsApp, Instagram, Chrome, Camera, Settings ya Battery boliye.")
            }
        }
    }

    private fun openPackage(pkg: String, label: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) launch(intent) else speak("$label install nahi hai.")
    }

    private fun launch(intent: Intent) {
        try { startActivity(intent) } catch (_: Exception) { speak("Is action ko phone support nahi karta.") }
    }

    private fun showDialer() = launch(Intent(Intent.ACTION_DIAL))
    private fun composeSms() = launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun JarvisScreen(onListen: ((String) -> Unit) -> Unit, onCommand: (String) -> Unit) {
    var heard by remember { mutableStateOf("Ready when you are.") }
    var command by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("ONLINE • READY") }
    val bg = Color(0xFF050B16)
    val cyan = Color(0xFF36D9FF)

    MaterialTheme(colorScheme = darkColorScheme(
        background = bg, surface = Color(0xFF101B2B), primary = cyan,
        onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(bg).padding(22.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(28.dp))
            Text("J.A.R.V.I.S", color = cyan, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("PERSONAL PHONE AGENT", color = Color.LightGray, fontSize = 11.sp, letterSpacing = 3.sp)
            Spacer(Modifier.height(32.dp))
            Box(
                Modifier.size(190.dp).background(Color(0xFF102B40), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size(150.dp).background(Color(0xFF16445B), CircleShape), contentAlignment = Alignment.Center) {
                    Text("AI", color = cyan, fontSize = 54.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(18.dp))
            Text(status, color = cyan, fontSize = 12.sp)
            Spacer(Modifier.height(24.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF101B2B)),
                shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("VOICE COMMAND", color = cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(heard, color = Color.White, fontSize = 16.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = {
                        status = "LISTENING..."
                        onListen { result ->
                            heard = result
                            command = result
                            status = "COMMAND RECEIVED"
                            onCommand(result)
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("🎙  TAP TO SPEAK") }
                }
            }
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = command, onValueChange = { command = it },
                label = { Text("Type a command") }, modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = {
                if (command.isNotBlank()) {
                    heard = command
                    status = "EXECUTING..."
                    onCommand(command)
                    status = "ONLINE • READY"
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("RUN COMMAND") }
            Spacer(Modifier.height(20.dp))
            Text("TRY: “YouTube kholo”, “WhatsApp kholo”, “Battery kitni hai”, “Settings kholo”",
                color = Color.LightGray, fontSize = 12.sp)
            Spacer(Modifier.height(18.dp))
            Text("Calls and SMS open the Android dialer/composer for your review. JARVIS cannot bypass the lock screen.",
                color = Color.Gray, fontSize = 11.sp)
        }
    }
}
